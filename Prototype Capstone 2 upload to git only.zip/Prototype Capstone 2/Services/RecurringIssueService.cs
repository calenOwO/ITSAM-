using Microsoft.EntityFrameworkCore;
using Prototype_Capstone_2.Models;

namespace Prototype_Capstone_2.Services
{
    public class RecurringIssueService
    {
        private readonly Prototype_Capstone_2Context _context;

        public RecurringIssueService(Prototype_Capstone_2Context context)
        {
            _context = context;
        }

        /// <summary>
        /// Get recurring issues by time period (only resolved tickets)
        /// </summary>
        public async Task<List<RecurringIssueDto>> GetRecurringIssuesByPeriodAsync(string timePeriod = "monthly", int threshold = 3)
        {
            var cutoffDate = GetCutoffDate(timePeriod);

            // Get RESOLVED tickets from the specified period only
            var ticketsByCategory = await _context.Ticketing
                .Where(t => t.TicketCreated >= cutoffDate && t.TicketStatus == "Resolved")
                .GroupBy(t => t.TicketIssueCategory)
                .Select(g => new
                {
                    Category = g.Key,
                    Count = g.Count(),
                    Tickets = g.ToList()
                })
                .OrderByDescending(g => g.Count)
                .ToListAsync();

            var recurringGroups = new List<RecurringIssueDto>();

            foreach (var categoryGroup in ticketsByCategory.Where(g => g.Count >= threshold))
            {
                // Extract common keywords from descriptions
                var keywords = ExtractCommonKeywords(categoryGroup.Tickets);

                recurringGroups.Add(new RecurringIssueDto
                {
                    Category = categoryGroup.Category,
                    Count = categoryGroup.Count,
                    Tickets = categoryGroup.Tickets,
                    Keywords = keywords,
                    Percentage = Math.Round((categoryGroup.Count / (double)ticketsByCategory.Sum(g => g.Count)) * 100, 1)
                });
            }

            return recurringGroups;
        }

        /// <summary>
        /// Get the top recurring issue by time period
        /// </summary>
        public async Task<RecurringIssueDto?> GetTopRecurringIssueAsync(string timePeriod = "monthly", int threshold = 3)
        {
            var recurring = await GetRecurringIssuesByPeriodAsync(timePeriod, threshold);
            return recurring.FirstOrDefault();
        }

        /// <summary>
        /// Get all category statistics by time period (only resolved tickets)
        /// </summary>
        public async Task<List<CategoryStatDto>> GetCategoryStatisticsByPeriodAsync(string timePeriod = "monthly")
        {
            var cutoffDate = GetCutoffDate(timePeriod);

            var categoryStats = await _context.Ticketing
                .Where(t => t.TicketCreated >= cutoffDate && t.TicketStatus == "Resolved")
                .GroupBy(t => t.TicketIssueCategory)
                .Select(g => new CategoryStatDto
                {
                    Category = g.Key,
                    Count = g.Count(),
                    Pending = 0,
                    InProgress = 0,
                    Resolved = g.Count()
                })
                .OrderByDescending(g => g.Count)
                .ToListAsync();

            return categoryStats;
        }

        private DateTime GetCutoffDate(string timePeriod)
        {
            return timePeriod.ToLower() switch
            {
                "weekly" => DateTime.UtcNow.AddDays(-7),
                "monthly" => DateTime.UtcNow.AddDays(-30),
                "yearly" => DateTime.UtcNow.AddYears(-1),
                "alltime" => DateTime.MinValue,
                _ => DateTime.UtcNow.AddDays(-30) // Default to monthly
            };
        }

        private string ExtractCommonKeywords(List<Ticketing> tickets)
        {
            if (tickets.Count == 0) return string.Empty;

            // Extract common words from descriptions
            var allWords = tickets
                .SelectMany(t => t.TicketDescription.Split(new[] { ' ', ',', '.', ';', ':' }, StringSplitOptions.RemoveEmptyEntries))
                .Where(w => w.Length > 3)
                .GroupBy(w => w.ToLower())
                .OrderByDescending(g => g.Count())
                .Take(3)
                .Select(g => g.Key);

            return string.Join(", ", allWords);
        }
    }

    public class RecurringIssueDto
    {
        public string Category { get; set; } = string.Empty;
        public int Count { get; set; }
        public List<Ticketing> Tickets { get; set; } = new();
        public string Keywords { get; set; } = string.Empty;
        public double Percentage { get; set; }
    }

    public class CategoryStatDto
    {
        public string Category { get; set; } = string.Empty;
        public int Count { get; set; }
        public int Pending { get; set; }
        public int InProgress { get; set; }
        public int Resolved { get; set; }
    }
}

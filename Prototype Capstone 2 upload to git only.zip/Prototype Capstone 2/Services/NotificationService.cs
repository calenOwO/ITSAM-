using Microsoft.EntityFrameworkCore;
using Prototype_Capstone_2.Models;

namespace Prototype_Capstone_2.Services
{
    public class NotificationService
    {
        private readonly Prototype_Capstone_2Context _context;
        private const int HOURS_LOOKBACK = 24; // Look for recent actions in the last 24 hours
        private const int MAX_NOTIFICATIONS = 5; // Maximum items to show

        public NotificationService(Prototype_Capstone_2Context context)
        {
            _context = context;
        }

        /// <summary>
        /// Get notifications for an Employee
        /// </summary>
        public async Task<EmployeeNotifications> GetEmployeeNotificationsAsync(string username)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == username);
            if (user == null)
                return new EmployeeNotifications();

            var fullName = $"{user.FirstName} {user.LastName}".Trim();
            var recentTime = DateTime.UtcNow.AddHours(-HOURS_LOOKBACK);

            // Get recently confirmed borrowing requests (accepted by admin)
            var approvedBorrowingRequests = await _context.BorrowingRequests
                .Where(r => r.BorrowerName == fullName && r.Status == "Confirmed")
                .OrderByDescending(r => r.RequestId)
                .Take(MAX_NOTIFICATIONS)
                .Select(r => new NotificationItem 
                { 
                    Id = r.RequestId.ToString(),
                    Title = $"Request #{r.RequestId} has been approved and confirmed",
                    Type = "borrowing",
                    Icon = "✓"
                })
                .ToListAsync();

            // Get recently rejected borrowing requests
            var rejectedBorrowingRequests = await _context.BorrowingRequests
                .Where(r => r.BorrowerName == fullName && r.Status == "Rejected")
                .OrderByDescending(r => r.RequestId)
                .Take(MAX_NOTIFICATIONS)
                .Select(r => new NotificationItem 
                { 
                    Id = r.RequestId.ToString(),
                    Title = $"Request #{r.RequestId} has been rejected",
                    Type = "borrowing_rejected",
                    Icon = "✗"
                })
                .ToListAsync();

            // Get recently completed borrowing requests (all items returned)
            var completedBorrowingRequests = await _context.BorrowingRequests
                .Where(r => r.BorrowerName == fullName && r.Status == "Completed")
                .OrderByDescending(r => r.RequestId)
                .Take(MAX_NOTIFICATIONS)
                .Select(r => new NotificationItem 
                { 
                    Id = r.RequestId.ToString(),
                    Title = $"Request #{r.RequestId} has been completed",
                    Type = "borrowing_completed",
                    Icon = "✓"
                })
                .ToListAsync();

            // Get recently assigned tickets (technician assigned to their ticket)
            var assignedTickets = await _context.Ticketing
                .Where(t => t.TicketUserName == fullName && !string.IsNullOrEmpty(t.TicketAssignedTo) && t.TicketStatus == "In Progress")
                .OrderByDescending(t => t.TicketCreated)
                .Take(MAX_NOTIFICATIONS)
                .Select(t => new NotificationItem 
                { 
                    Id = t.TicketId.ToString(),
                    Title = $"Your ticket #{t.TicketId} has been assigned to a technician",
                    Type = "ticket_assigned",
                    Icon = "🎫"
                })
                .ToListAsync();

            // Get recently resolved tickets
            var resolvedTickets = await _context.Ticketing
                .Where(t => t.TicketUserName == fullName && t.TicketStatus == "Resolved" && t.TicketCreated >= recentTime)
                .OrderByDescending(t => t.TicketCreated)
                .Take(MAX_NOTIFICATIONS)
                .Select(t => new NotificationItem 
                { 
                    Id = t.TicketId.ToString(),
                    Title = $"Your ticket #{t.TicketId} has been resolved",
                    Type = "ticket_resolved",
                    Icon = "✓"
                })
                .ToListAsync();

            var allNotifications = new List<NotificationItem>();
            allNotifications.AddRange(approvedBorrowingRequests);
            allNotifications.AddRange(rejectedBorrowingRequests);
            allNotifications.AddRange(completedBorrowingRequests);
            allNotifications.AddRange(assignedTickets);
            allNotifications.AddRange(resolvedTickets);

            // Limit to max 5 total
            allNotifications = allNotifications.Take(MAX_NOTIFICATIONS).ToList();

            return new EmployeeNotifications
            {
                Notifications = allNotifications,
                TotalNotifications = allNotifications.Count
            };
        }

        /// <summary>
        /// Get notifications for a Technician
        /// </summary>
        public async Task<TechnicianNotifications> GetTechnicianNotificationsAsync(string username)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Username == username);
            if (user == null)
                return new TechnicianNotifications();

            var fullName = $"{user.FirstName} {user.LastName}".Trim();
            var recentTime = DateTime.UtcNow.AddHours(-HOURS_LOOKBACK);

            // Pending tickets assigned to them
            var pendingAssignedTickets = await _context.Ticketing
                .Where(t => t.TicketAssignedTo == username && t.TicketStatus == "In Progress")
                .OrderByDescending(t => t.TicketCreated)
                .Take(MAX_NOTIFICATIONS)
                .Select(t => new NotificationItem 
                { 
                    Id = t.TicketId.ToString(),
                    Title = $"Ticket #{t.TicketId} is assigned to you",
                    Type = "assigned_ticket",
                    Icon = "🎫"
                })
                .ToListAsync();

            // Tickets they created that have been assigned to a technician (recently assigned)
            var createdTicketsWithAssignment = await _context.Ticketing
                .Where(t => t.TicketUserName == fullName && !string.IsNullOrEmpty(t.TicketAssignedTo) && t.TicketStatus == "In Progress")
                .OrderByDescending(t => t.TicketCreated)
                .Take(MAX_NOTIFICATIONS)
                .Select(t => new NotificationItem 
                { 
                    Id = t.TicketId.ToString(),
                    Title = $"Your ticket #{t.TicketId} has been assigned",
                    Type = "created_ticket_assigned",
                    Icon = "🎫"
                })
                .ToListAsync();

            // Recently confirmed borrowing requests in their name (accepted by admin)
            var confirmedBorrowingRequests = await _context.BorrowingRequests
                .Where(r => r.BorrowerName == fullName && r.Status == "Confirmed" && r.RequestId > 0)
                .OrderByDescending(r => r.RequestId)
                .Take(MAX_NOTIFICATIONS)
                .Select(r => new NotificationItem 
                { 
                    Id = r.RequestId.ToString(),
                    Title = $"Request #{r.RequestId} has been approved and confirmed",
                    Type = "borrowing",
                    Icon = "✓"
                })
                .ToListAsync();

            // Recently completed borrowing requests in their name
            var completedBorrowingRequests = await _context.BorrowingRequests
                .Where(r => r.BorrowerName == fullName && r.Status == "Completed" && r.RequestId > 0)
                .OrderByDescending(r => r.RequestId)
                .Take(MAX_NOTIFICATIONS)
                .Select(r => new NotificationItem 
                { 
                    Id = r.RequestId.ToString(),
                    Title = $"Request #{r.RequestId} has been completed",
                    Type = "borrowing_completed",
                    Icon = "✓"
                })
                .ToListAsync();

            // Recently rejected borrowing requests in their name
            var rejectedBorrowingRequests = await _context.BorrowingRequests
                .Where(r => r.BorrowerName == fullName && r.Status == "Rejected" && r.RequestId > 0)
                .OrderByDescending(r => r.RequestId)
                .Take(MAX_NOTIFICATIONS)
                .Select(r => new NotificationItem 
                { 
                    Id = r.RequestId.ToString(),
                    Title = $"Request #{r.RequestId} has been rejected",
                    Type = "borrowing_rejected",
                    Icon = "✗"
                })
                .ToListAsync();

            var allNotifications = new List<NotificationItem>();
            allNotifications.AddRange(pendingAssignedTickets);
            allNotifications.AddRange(createdTicketsWithAssignment);
            allNotifications.AddRange(confirmedBorrowingRequests);
            allNotifications.AddRange(rejectedBorrowingRequests);
            allNotifications.AddRange(completedBorrowingRequests);

            // Limit to max 5 total
            allNotifications = allNotifications.Take(MAX_NOTIFICATIONS).ToList();

            return new TechnicianNotifications
            {
                Notifications = allNotifications,
                TotalNotifications = allNotifications.Count
            };
        }

        /// <summary>
        /// Get notifications for an Admin
        /// </summary>
        public async Task<AdminNotifications> GetAdminNotificationsAsync()
        {
            var recentTime = DateTime.UtcNow.AddHours(-HOURS_LOOKBACK);

            // Recently changed pending borrowing requests
            var pendingBorrowingRequests = await _context.BorrowingRequests
                .Where(r => r.Status == "Pending")
                .OrderByDescending(r => r.RequestId)
                .Take(MAX_NOTIFICATIONS)
                .Select(r => new NotificationItem 
                { 
                    Id = r.RequestId.ToString(),
                    Title = $"Request #{r.RequestId} is pending approval",
                    Type = "pending_borrowing",
                    Icon = "📋"
                })
                .ToListAsync();

            // Recently changed unassigned tickets
            var unassignedTickets = await _context.Ticketing
                .Where(t => string.IsNullOrEmpty(t.TicketAssignedTo) && t.TicketStatus == "Pending")
                .OrderByDescending(t => t.TicketCreated)
                .Take(MAX_NOTIFICATIONS)
                .Select(t => new NotificationItem 
                { 
                    Id = t.TicketId.ToString(),
                    Title = $"Ticket #{t.TicketId} needs assignment",
                    Type = "unassigned_ticket",
                    Icon = "🎫"
                })
                .ToListAsync();

            // Recently resolved tickets (from the last 24 hours)
            var resolvedTickets = await _context.Ticketing
                .Where(t => t.TicketStatus == "Resolved" && t.TicketCreated >= recentTime)
                .OrderByDescending(t => t.TicketCreated)
                .Take(MAX_NOTIFICATIONS)
                .Select(t => new NotificationItem 
                { 
                    Id = t.TicketId.ToString(),
                    Title = $"Ticket #{t.TicketId} has been resolved",
                    Type = "resolved_ticket",
                    Icon = "✓"
                })
                .ToListAsync();

            // Pending user approvals
            var pendingUserApprovals = await _context.Users
                .Where(u => u.ApprovalStatus == "Pending")
                .OrderByDescending(u => u.UserCreated)
                .Take(MAX_NOTIFICATIONS)
                .Select(u => new NotificationItem 
                { 
                    Id = u.UserId.ToString(),
                    Title = $"{u.FirstName} {u.LastName} is pending approval",
                    Type = "pending_user",
                    Icon = "👥"
                })
                .ToListAsync();

            var allNotifications = new List<NotificationItem>();
            allNotifications.AddRange(pendingBorrowingRequests);
            allNotifications.AddRange(unassignedTickets);
            allNotifications.AddRange(resolvedTickets);
            allNotifications.AddRange(pendingUserApprovals);

            // Limit to max 5 total
            allNotifications = allNotifications.Take(MAX_NOTIFICATIONS).ToList();

            return new AdminNotifications
            {
                Notifications = allNotifications,
                TotalNotifications = allNotifications.Count
            };
        }
    }

    public class NotificationItem
    {
        public string Id { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty;
        public string Icon { get; set; } = string.Empty;
    }

    public class EmployeeNotifications
    {
        public List<NotificationItem> Notifications { get; set; } = new();
        public int TotalNotifications { get; set; }
    }

    public class TechnicianNotifications
    {
        public List<NotificationItem> Notifications { get; set; } = new();
        public int TotalNotifications { get; set; }
    }

    public class AdminNotifications
    {
        public List<NotificationItem> Notifications { get; set; } = new();
        public int TotalNotifications { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace Prototype_Capstone_2.Models
{
    public class CreateBorrowingViewModel
    {
        [Required(ErrorMessage = "Borrower name is Required.")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Borrower name must be between 2 and 50 characters.")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Borrower name can only contain letters and spaces.")]
        public string BorrowerName { get; set; } = string.Empty;

        [StringLength(100)]
        public string BorrowerDivision { get; set; } = string.Empty;

        [Required(ErrorMessage = "Borrow date is required.")]
        [DataType(DataType.Date)]
        public DateTime BorrowDate { get; set; } = DateTime.Today;

        [Required(ErrorMessage = "At least one equipment item must be selected.")]
        public List<int> SelectedEquipmentIds { get; set; } = new List<int>();

        [Required(ErrorMessage = "Quantities must be provided.")]
        public List<int> SelectedQuantities { get; set; } = new List<int>();

        // For display purposes
        public List<Equipment>? EquipmentList { get; set; }
    }
}
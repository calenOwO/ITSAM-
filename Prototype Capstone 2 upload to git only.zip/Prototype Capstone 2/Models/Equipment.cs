﻿using System.ComponentModel.DataAnnotations;

namespace Prototype_Capstone_2.Models
{
    public class Equipment
    {
        [Key]
        public int EquipmentID { get; set; }

        [Required(ErrorMessage = "Equipment name is required.")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Equipment name must be between 2 and 50 characters.")]
        public string EquipmentName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Equipment description is required.")]
        [StringLength(100, MinimumLength = 5, ErrorMessage = "Equipment description must be between 5 and 50 characters.")]
        public string EquipmentDesc { get; set; } = string.Empty;

        [Required(ErrorMessage = "Equipment quantity is required.")]
        [RegularExpression(@"^\d+$", ErrorMessage = "Equipment quantity must be a positive integer.")]
        [Range(1, 99999, ErrorMessage = "Equipment quantity must be between 1 and 99999.")]
        public int EquipmentQuantity { get; set; }

        [Required(ErrorMessage = "Equipment available quantity is required.")]
        [RegularExpression(@"^\d+$", ErrorMessage = "Equipment available quantity must be a positive integer.")]
        [Range(0, 99999, ErrorMessage = "Equipment available quantity must be between 0 and 99999.")]
        public int EquipmentAvailableQuantity { get; set; }

        [Required(ErrorMessage = "Equipment date created is required.")]
        [DataType(DataType.Date)]
        public DateTime EquipmentDateCreated { get; set; } = DateTime.UtcNow;

        // One-to-many 
        public virtual ICollection<EquipmentItem> EquipmentItems { get; set; } = new List<EquipmentItem>();
    }
}


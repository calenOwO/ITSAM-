﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Prototype_Capstone_2.Models
{
    // Tracks one physical EquipmentItem that was assigned to fulfil part of a
    // Borrowing line's Quantity. A single Borrowing (e.g. "3x Hammer") will have
    // up to 3 of these once accepted, one per physical unit handed out.
    public class BorrowingEquipmentItem
    {
        [Key]
        public int BorrowingEquipmentItemId { get; set; }

        [ForeignKey("Borrowing")]
        public int BorrowingId { get; set; }
        public virtual Borrowing Borrowing { get; set; } = null!;

        [ForeignKey("EquipmentItem")]
        public int EquipmentItemID { get; set; }
        public virtual EquipmentItem EquipmentItem { get; set; } = null!;

        // Per-unit lifecycle: In-Use -> Returned -> Completed (or Damaged on inspection)
        public string Status { get; set; } = "In-Use";

        [DataType(DataType.Date)]
        public DateTime? ReturnDate { get; set; }
    }
}

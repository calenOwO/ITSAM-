﻿using Prototype_Capstone_2.Services;

namespace Prototype_Capstone_2.Models
{
    public class ReportsHomeViewModel
    {
        public string ActiveTab { get; set; } = "inventory";
        public string? CurrentSearch { get; set; }
        public string? CurrentSort { get; set; }
        public string? CurrentStatus { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? TimePeriod { get; set; } = "monthly";

        // Inventory
        public List<Equipment> InventoryRows { get; set; } = new();
        public int InvTotalItems { get; set; }
        public int InvAvailable { get; set; }
        public int InvUnavailable { get; set; }
        public int LowStockThreshold { get; set; } = 5;

        // Equipment Status for Pie Chart
        public int EquipmentTotal { get; set; }
        public int EquipmentAvailable { get; set; }
        public int EquipmentBorrowed { get; set; }
        public int EquipmentDamaged { get; set; }
        public int EquipmentLost { get; set; }

        // Borrowing
        public List<BorrowingRequests> BorrowingRows { get; set; } = new();
        public int BorTotalRequests { get; set; }
        public int BorPending { get; set; }
        public int BorActive { get; set; }
        public int BorDamagedOrLost { get; set; }

        // Borrowing by Division
        public Dictionary<string, int> BorrowingByDivision { get; set; } = new();

        // Ticketing
        public List<Ticketing> TicketingRows { get; set; } = new();
        public int TickAssigned { get; set; }
        public int TickUnassigned { get; set; }
        public int TickResolved { get; set; }
        public int TickTotal { get; set; }

        // Ticketing by Division
        public Dictionary<string, int> TicketingByDivision { get; set; } = new();

        // Ticketing by Issue Category
        public Dictionary<string, int> TicketingByCategory { get; set; } = new();

        // Recurring Issues
        public List<CategoryStatDto> CategoryStats { get; set; } = new();
        public RecurringIssueDto? TopRecurringIssue { get; set; }
        public int RecurringIssueCount { get; set; }
    }
}

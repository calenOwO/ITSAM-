using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Prototype_Capstone_2.Models
{
    public class Users
    {
        [Key]
        public int UserId { get; set; }

        [Required(ErrorMessage = "User role is required")]
        [StringLength(30)]
        public string UserRole { get; set; } = "Employee";

        [Required(ErrorMessage = "User division is required")]
        [StringLength(100)]
        public string UserDivision { get; set; } = string.Empty;

        [Required(ErrorMessage = "First name is required")]
        [RegularExpression(@"^[a-zA-Z]+(?:[ '-][a-zA-Z]+)*$", ErrorMessage = "First name must contain letters only")]
        [StringLength(50)]
        public string FirstName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Last name is required")]
        [RegularExpression(@"^[a-zA-Z]+(?:[ '-][a-zA-Z]+)*$", ErrorMessage = "Last name must contain letters only")]
        [StringLength(50)]
        public string LastName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        [StringLength(100)]
        [Column("UserEmail")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Phone number is required")]
        [RegularExpression(@"^[0-9]{10,15}$", ErrorMessage = "Phone number must contain 10 to 15 digits")]
        [StringLength(15, MinimumLength = 10)]
        public string PhoneNumber { get; set; } = string.Empty;

        [Required(ErrorMessage = "Username is required")]
        [StringLength(50)]
        [Column("UserName")]
        public string Username { get; set; } = string.Empty;

        // PBKDF2 hash
        [Required]
        [Column("UserPassword")]
        public string PasswordHash { get; set; } = string.Empty;

        [Required]
        public DateTime UserCreated { get; set; } = DateTime.UtcNow;

        [StringLength(20)]
        public string ApprovalStatus { get; set; } = "Pending";  

        [NotMapped]
        public string FullName => $"{FirstName} {LastName}".Trim();

        // (BorrowingRequests.RequesterUserId, Ticketing.SubmittedByUserId/AssignedToUserId).
        public virtual ICollection<BorrowingRequests> BorrowingRequests { get; set; } = new List<BorrowingRequests>();

        public virtual ICollection<Ticketing> SubmittedTickets { get; set; } = new List<Ticketing>();

        public virtual ICollection<Ticketing> AssignedTickets { get; set; } = new List<Ticketing>();
    }
}

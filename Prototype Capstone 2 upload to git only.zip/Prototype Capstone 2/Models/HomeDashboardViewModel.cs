using Prototype_Capstone_2.Services;

namespace Prototype_Capstone_2.Models
{
    public class AdminHomeDashboardViewModel
    {
        public int TotalPhysicalItems { get; set; }
        public int AvailablePhysicalItems { get; set; }
        public int BorrowedPhysicalItems { get; set; }
        public int DamagedPhysicalItems { get; set; }
        public int LostPhysicalItems { get; set; }
        public int PendingBorrowingRequests { get; set; }
        public int ActiveBorrowings { get; set; }
        public int CompletedBorrowings { get; set; }
        public int UnassignedTickets { get; set; }
        public int AssignedTickets { get; set; }
        public int ResolvedTickets { get; set; }
        public int UserCount { get; set; }
        public int PendingUserApprovals { get; set; }

        // Recurring issues data
        public string SelectedTimePeriod { get; set; } = "monthly";
        public List<RecurringIssueDto> TopRecurringIssues { get; set; } = new();
        public RecurringIssueDto? MostCommonIssue { get; set; }
    }
}

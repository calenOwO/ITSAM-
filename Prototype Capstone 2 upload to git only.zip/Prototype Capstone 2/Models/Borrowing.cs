using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace Prototype_Capstone_2.Models

{
    public class Borrowing
    {
        [Key]
        public int BorrowingId { get; set; }

        [Required(ErrorMessage="Borrower name is Required.")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Borrower name must be between 2 and 50 characters.")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Borrower name can only contain letters and spaces.")]
        public string BorrowerName { get; set; } = string.Empty;

        [ForeignKey("Equipment")]
        [Required(ErrorMessage = "Equipment is required.")]
        public int EquipmentID { get; set; }
   
        
        [Required(ErrorMessage = "Quantity is required.")]
        [Range(1, 99, ErrorMessage = "Quantity must be between 1 and 99.")]
        public int Quantity { get; set; } = 1;

        [Required(ErrorMessage = "Borrow date is required.")]
        [DataType(DataType.Date)]
        public DateTime BorrowDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? ReturnDate { get; set; }

        // Rollup status for the whole line (Pending / In-Use / Under Inspection / Completed),
        // derived from the statuses of the individual AssignedItems once accepted.
        public string Status { get; set; } = string.Empty;

        [ForeignKey("BorrowingRequest")]
        public int RequestId { get; set; }

        public virtual BorrowingRequests BorrowingRequest { get; set; } = null!;

        public virtual Equipment Equipment { get; set; } = null!;

        // Replaces the old single EquipmentItemID/EquipmentItem: a Quantity > 1
        // line needs multiple physical items, so this is now a collection,
        // populated once the request is accepted.
        public virtual ICollection<BorrowingEquipmentItem> AssignedItems { get; set; } = new List<BorrowingEquipmentItem>();
    }
}

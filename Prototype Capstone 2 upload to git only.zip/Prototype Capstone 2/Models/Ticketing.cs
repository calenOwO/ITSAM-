using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Prototype_Capstone_2.Models
{
    public class Ticketing
    {
        [Key]
        public int TicketId { get; set; }

        // Links this ticket back to the logged-in account that submitted it.
        // Nullable to keep existing rows valid; TicketUserName is kept as the
        // display/fallback value (e.g. for tickets submitted before this FK existed).
        [ForeignKey("SubmittedByUser")]
        public int? SubmittedByUserId { get; set; }

        public virtual Users? SubmittedByUser { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "Name is required")]
        [StringLength(100)]
        public string TicketUserName { get; set; } = string.Empty;

        [Display(Name = "Division")]
        [Required(ErrorMessage = "Division is required")]
        [StringLength(100)]
        public string TicketDivision { get; set; } = string.Empty;

        [Display(Name = "Issue Category")]
        [Required(ErrorMessage = "Pick an issue category")]
        [StringLength(100)]
        public string TicketIssueCategory { get; set; } = string.Empty;

        [Display(Name = "Ticket Date")]
        [DataType(DataType.Date)]
        public DateTime TicketDateCreated { get; set; } = DateTime.Today;

        [Display(Name = "Time Fixed")]
        [DataType(DataType.DateTime)]
        public DateTime? TicketTimeFixed { get; set; }

        [Display(Name = "Person Notified")]
        [StringLength(100)]
        public string TicketPersonNotified { get; set; } = string.Empty;

        [Display(Name = "Detailed Narration of the Incident")]
        [Required(ErrorMessage = "Incident narration is required")]
        [DataType(DataType.MultilineText)]
        [StringLength(3000)]
        public string TicketDescription { get; set; } = string.Empty;

        [Display(Name = "Resolution")]
        [DataType(DataType.MultilineText)]
        [StringLength(3000)]
        public string TicketResolution { get; set; } = string.Empty;

        [Display(Name = "Assigned Personnel")]
        [StringLength(100)]
        public string TicketAssignedTo { get; set; } = string.Empty;

        // Links to the technician account assigned to resolve this ticket.
        // Nullable since a ticket starts unassigned; TicketAssignedTo (username)
        // is kept for the existing lookups/display logic.
        [ForeignKey("AssignedToUser")]
        public int? AssignedToUserId { get; set; }

        public virtual Users? AssignedToUser { get; set; }

        [Display(Name = "Status")]
        [StringLength(50)]
        public string TicketStatus { get; set; } = "Pending";

        [Display(Name = "Priority")]
        [StringLength(50)]
        public string TicketPriority { get; set; } = "Normal";

        [Display(Name = "Created")]
        [DataType(DataType.DateTime)]
        public DateTime TicketCreated { get; set; } = DateTime.UtcNow;
    }
}

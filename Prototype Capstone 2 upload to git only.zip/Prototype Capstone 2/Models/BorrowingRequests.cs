﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Prototype_Capstone_2.Models
{
    public class BorrowingRequests
    {
        [Key]
        public int RequestId { get; set; }

        [Required(ErrorMessage = "Borrower name is Required.")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Borrower name must be between 2 and 50 characters.")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Borrower name can only contain letters and spaces.")]
        public string BorrowerName { get; set; } = string.Empty;

        // Links this request back to the logged-in account that submitted it.
        // Nullable so existing/legacy rows (and any walk-in flow without a login)
        // remain valid; BorrowerName is kept as the display/fallback value.
        [ForeignKey("RequesterUser")]
        public int? RequesterUserId { get; set; }

        public virtual Users? RequesterUser { get; set; }

        [StringLength(100)]
        public string BorrowerDivision { get; set; } = string.Empty;

        [Required(ErrorMessage = "Borrow date is required.")]
        [DataType(DataType.Date)]
        public DateTime BorrowDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime? ReturnDate { get; set; }

        public string Status { get; set; } = "Pending";

        [StringLength(500)]
        public string? Remarks { get; set; }

        public virtual ICollection<Borrowing> Borrowings { get; set; } = new List<Borrowing>();
    }
}

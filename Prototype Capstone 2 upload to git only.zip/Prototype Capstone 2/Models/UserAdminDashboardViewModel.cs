namespace Prototype_Capstone_2.Models
{
    public class UserAdminDashboardViewModel
    {
        public List<Users> PendingUsers { get; set; } = new();
        public List<Users> ApprovedUsers { get; set; } = new();
    }
}

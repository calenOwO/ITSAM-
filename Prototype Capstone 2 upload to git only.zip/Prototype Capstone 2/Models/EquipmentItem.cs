﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Prototype_Capstone_2.Models
{
    public class EquipmentItem
    {
        [Key]
        public int ItemID { get; set; }

        [ForeignKey("Equipment")]
        public int EquipmentID { get; set; }

        public string ItemLabel { get; set; } = string.Empty;

        public string Status { get; set; } = string.Empty;

        // Reference to parent
        public virtual Equipment Equipment { get; set; } = null!;
    }
}

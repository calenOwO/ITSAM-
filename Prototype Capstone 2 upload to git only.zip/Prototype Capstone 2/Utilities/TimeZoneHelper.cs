using System;

namespace Prototype_Capstone_2.Utilities
{
    /// <summary>
    /// Ticket timestamps (e.g. TicketTimeFixed) are stored in the database as UTC
    /// ("timestamp with time zone" columns require it). These helpers convert
    /// between UTC (for storage) and Philippine local time (for display/input),
    /// so times shown to the user match the wall-clock time they expect.
    /// </summary>
    public static class TimeZoneHelper
    {
        public static readonly TimeZoneInfo PhilippineTimeZone =
            TimeZoneInfo.FindSystemTimeZoneById("Asia/Manila");

        public static DateTime ToPhilippineTime(this DateTime utcDateTime)
        {
            var utc = utcDateTime.Kind == DateTimeKind.Utc
                ? utcDateTime
                : DateTime.SpecifyKind(utcDateTime, DateTimeKind.Utc);

            return TimeZoneInfo.ConvertTimeFromUtc(utc, PhilippineTimeZone);
        }

        public static DateTime? ToPhilippineTime(this DateTime? utcDateTime)
        {
            return utcDateTime.HasValue ? utcDateTime.Value.ToPhilippineTime() : null;
        }

        public static DateTime ToUtcFromPhilippineTime(this DateTime philippineDateTime)
        {
            var unspecified = DateTime.SpecifyKind(philippineDateTime, DateTimeKind.Unspecified);
            return TimeZoneInfo.ConvertTimeToUtc(unspecified, PhilippineTimeZone);
        }

        public static DateTime? ToUtcFromPhilippineTime(this DateTime? philippineDateTime)
        {
            return philippineDateTime.HasValue ? philippineDateTime.Value.ToUtcFromPhilippineTime() : null;
        }
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Prototype_Capstone_2.Models;
using Prototype_Capstone_2.Services;
using System.Diagnostics;

namespace Prototype_Capstone_2.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly Prototype_Capstone_2Context _context;
        private readonly RecurringIssueService _recurringIssueService;

        public HomeController(ILogger<HomeController> logger, Prototype_Capstone_2Context context, RecurringIssueService recurringIssueService)
        {
            _logger = logger;
            _context = context;
            _recurringIssueService = recurringIssueService;
        }

        public IActionResult Index() => RedirectToAction(nameof(Dashboard));

        public IActionResult Privacy() => View();

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Reports(string tab = "inventory", string? search = null, string? sort = null,
string? status = null, DateTime? startDate = null, DateTime? endDate = null, string? timePeriod = null)
        {
            tab = string.IsNullOrWhiteSpace(tab) ? "inventory" : tab.ToLower();
            timePeriod = string.IsNullOrWhiteSpace(timePeriod) ? "monthly" : timePeriod.ToLower();

            var model = new ReportsHomeViewModel
            {
                ActiveTab = tab,
                CurrentSearch = search,
                CurrentSort = sort,
                CurrentStatus = status,
                StartDate = startDate,
                EndDate = endDate,
                TimePeriod = timePeriod
            };

            // Load all data for all charts
            await LoadInventory(model);
            await LoadBorrowing(model);
            await LoadTicketing(model);
            await LoadRecurringIssues(model);

            return View(model);
        }

        /// <summary>
        /// Convert time period to cutoff date for filtering
        /// </summary>
        private DateTime GetCutoffDateFromPeriod(string timePeriod)
        {
            return timePeriod?.ToLower() switch
            {
                "weekly" => DateTime.UtcNow.AddDays(-7),
                "monthly" => DateTime.UtcNow.AddDays(-30),
                "yearly" => DateTime.UtcNow.AddYears(-1),
                "alltime" => DateTime.MinValue,
                _ => DateTime.UtcNow.AddDays(-30) // Default to monthly
            };
        }

        private async Task LoadInventory(ReportsHomeViewModel model)
        {
            const int lowStockThreshold = 5;
            var query = _context.Equipment.AsQueryable();

            // Apply time period filter
            var cutoffDate = GetCutoffDateFromPeriod(model.TimePeriod);
            query = query.Where(e => e.EquipmentDateCreated >= cutoffDate);

            if (!string.IsNullOrWhiteSpace(model.CurrentSearch))
                query = query.Where(e => e.EquipmentName.Contains(model.CurrentSearch) || e.EquipmentDesc.Contains(model.CurrentSearch));

            if (model.StartDate.HasValue)
                query = query.Where(e => e.EquipmentDateCreated.Date >= model.StartDate.Value.Date);
            if (model.EndDate.HasValue)
                query = query.Where(e => e.EquipmentDateCreated.Date <= model.EndDate.Value.Date);

            query = model.CurrentSort switch
            {
                "za" => query.OrderByDescending(e => e.EquipmentName),
                "stock" => query.OrderBy(e => e.EquipmentAvailableQuantity),
                _ => query.OrderBy(e => e.EquipmentName),
            };

            var list = await query.ToListAsync();

            if (!string.IsNullOrWhiteSpace(model.CurrentStatus) && model.CurrentStatus != "All statuses")
            {
                list = model.CurrentStatus switch
                {
                    "Out of stock" => list.Where(e => e.EquipmentAvailableQuantity == 0).ToList(),
                    "Low stock" => list.Where(e => e.EquipmentAvailableQuantity > 0 && e.EquipmentAvailableQuantity <= lowStockThreshold).ToList(),
                    "In stock" => list.Where(e => e.EquipmentAvailableQuantity > lowStockThreshold).ToList(),
                    _ => list
                };
            }

            model.InventoryRows = list;
            model.LowStockThreshold = lowStockThreshold;
            model.InvTotalItems = list.Sum(e => e.EquipmentQuantity);
            model.InvAvailable = list.Count(e => e.EquipmentAvailableQuantity > 0);
            model.InvUnavailable = list.Count(e => e.EquipmentAvailableQuantity == 0);

            // Get equipment status from EquipmentItems
            var equipmentItems = await _context.EquipmentItem.ToListAsync();
            model.EquipmentTotal = equipmentItems.Count;
            model.EquipmentAvailable = equipmentItems.Count(e => e.Status == "Available");
            model.EquipmentBorrowed = equipmentItems.Count(e => e.Status == "Borrowed");
            model.EquipmentDamaged = equipmentItems.Count(e => e.Status == "Damaged");
            model.EquipmentLost = equipmentItems.Count(e => e.Status == "Lost");
        }

        private async Task LoadBorrowing(ReportsHomeViewModel model)
        {
            var cutoffDate = GetCutoffDateFromPeriod(model.TimePeriod);
            var requestQuery = _context.BorrowingRequests.AsQueryable();

            // Apply time period filter
            requestQuery = requestQuery.Where(b => b.BorrowDate >= cutoffDate);

            if (!string.IsNullOrWhiteSpace(model.CurrentSearch))
                requestQuery = requestQuery.Where(b => b.BorrowerName.Contains(model.CurrentSearch) || b.BorrowerDivision.Contains(model.CurrentSearch));

            if (model.StartDate.HasValue)
                requestQuery = requestQuery.Where(b => b.BorrowDate.Date >= model.StartDate.Value.Date);
            if (model.EndDate.HasValue)
                requestQuery = requestQuery.Where(b => b.BorrowDate.Date <= model.EndDate.Value.Date);

            if (!string.IsNullOrWhiteSpace(model.CurrentStatus) && model.CurrentStatus != "All statuses")
                requestQuery = requestQuery.Where(b => b.Status == model.CurrentStatus);

            var requests = await requestQuery.ToListAsync();

            model.BorrowingRows = requests;
            model.BorTotalRequests = requests.Count;
            model.BorPending = requests.Count(b => b.Status == "Pending");
            model.BorActive = requests.Count(b => b.Status == "In-Use");
            model.BorDamagedOrLost = requests.Count(b => b.Status == "Damaged" || b.Status == "Lost");

            // Get borrowing items by division - only completed borrowings with related request data
            var allBorrowings = await _context.Borrowing
                .Include(b => b.BorrowingRequest)
                .Where(b => b.Status == "Completed" && b.BorrowingRequest.BorrowDate >= cutoffDate)
                .ToListAsync();

            model.BorrowingByDivision = allBorrowings
                .GroupBy(b => string.IsNullOrEmpty(b.BorrowingRequest.BorrowerDivision) ? "Unassigned" : b.BorrowingRequest.BorrowerDivision)
                .OrderByDescending(g => g.Count())
                .ToDictionary(g => g.Key, g => g.Count());
        }

        private async Task LoadTicketing(ReportsHomeViewModel model)
        {
            var cutoffDate = GetCutoffDateFromPeriod(model.TimePeriod);
            var query = _context.Ticketing.AsQueryable();

            // Apply time period filter
            query = query.Where(t => t.TicketCreated >= cutoffDate);

            if (!string.IsNullOrWhiteSpace(model.CurrentSearch))
                query = query.Where(t => t.TicketUserName.Contains(model.CurrentSearch)
                    || t.TicketIssueCategory.Contains(model.CurrentSearch)
                    || t.TicketAssignedTo.Contains(model.CurrentSearch));

            if (model.StartDate.HasValue)
                query = query.Where(t => t.TicketCreated.Date >= model.StartDate.Value.Date);
            if (model.EndDate.HasValue)
                query = query.Where(t => t.TicketCreated.Date <= model.EndDate.Value.Date);

            if (!string.IsNullOrWhiteSpace(model.CurrentStatus) && model.CurrentStatus != "All statuses")
                query = query.Where(t => t.TicketStatus == model.CurrentStatus);

            query = model.CurrentSort switch
            {
                "priority" => query.OrderByDescending(t => t.TicketPriority == "Critical").ThenByDescending(t => t.TicketPriority == "High"),
                "oldest" => query.OrderBy(t => t.TicketCreated),
                _ => query.OrderByDescending(t => t.TicketCreated),
            };

            var list = await query.ToListAsync();

            model.TicketingRows = list;
            model.TickTotal = list.Count;
            model.TickAssigned = list.Count(t => !string.IsNullOrEmpty(t.TicketAssignedTo));
            model.TickUnassigned = list.Count(t => string.IsNullOrEmpty(t.TicketAssignedTo));
            model.TickResolved = list.Count(t => t.TicketStatus == "Resolved");

            // Get ticketing by division - only resolved tickets
            var resolvedTickets = list.Where(t => t.TicketStatus == "Resolved").ToList();
            model.TicketingByDivision = resolvedTickets
                .GroupBy(t => string.IsNullOrEmpty(t.TicketDivision) ? "Unassigned" : t.TicketDivision)
                .OrderByDescending(g => g.Count())
                .ToDictionary(g => g.Key, g => g.Count());

            // Get ticketing by issue category - only resolved tickets
            model.TicketingByCategory = resolvedTickets
                .GroupBy(t => string.IsNullOrEmpty(t.TicketIssueCategory) ? "Uncategorized" : t.TicketIssueCategory)
                .OrderByDescending(g => g.Count())
                .ToDictionary(g => g.Key, g => g.Count());
        }

        private async Task LoadRecurringIssues(ReportsHomeViewModel model)
        {
            var timePeriod = model.TimePeriod ?? "monthly";
            var categoryStats = await _recurringIssueService.GetCategoryStatisticsByPeriodAsync(timePeriod);

            // Get recurring issues (3+ occurrences)
            var recurring = await _recurringIssueService.GetRecurringIssuesByPeriodAsync(timePeriod, threshold: 3);
            var topRecurring = await _recurringIssueService.GetTopRecurringIssueAsync(timePeriod, threshold: 3);

            model.CategoryStats = categoryStats;
            model.TopRecurringIssue = topRecurring;
            model.RecurringIssueCount = recurring.Count;
        }

        public async Task<IActionResult> Dashboard(string? timePeriod = null)
        {
            timePeriod = timePeriod ?? "monthly";

            if (User.IsInRole("Admin"))
            {
                // Get recurring issues based on selected time period
                var recurringIssues = await _recurringIssueService.GetRecurringIssuesByPeriodAsync(timePeriod, threshold: 1);
                var topIssue = recurringIssues.FirstOrDefault();

                var model = new AdminHomeDashboardViewModel
                {
                    TotalPhysicalItems = await _context.EquipmentItem.CountAsync(),
                    AvailablePhysicalItems = await _context.EquipmentItem.CountAsync(i => i.Status == "Available"),
                    BorrowedPhysicalItems = await _context.EquipmentItem.CountAsync(i => i.Status == "Borrowed"),
                    DamagedPhysicalItems = await _context.EquipmentItem.CountAsync(i => i.Status == "Damaged"),
                    LostPhysicalItems = await _context.EquipmentItem.CountAsync(i => i.Status == "Lost"),
                    PendingBorrowingRequests = await _context.BorrowingRequests.CountAsync(r => r.Status == "Pending"),
                    ActiveBorrowings = await _context.BorrowingEquipmentItem.CountAsync(i => i.Status == "In-Use"),
                    CompletedBorrowings = await _context.BorrowingRequests.CountAsync(r => r.Status == "Completed"),
                    UnassignedTickets = await _context.Ticketing.CountAsync(t => string.IsNullOrEmpty(t.TicketAssignedTo)),
                    AssignedTickets = await _context.Ticketing.CountAsync(t => !string.IsNullOrEmpty(t.TicketAssignedTo) && t.TicketStatus != "Resolved"),
                    ResolvedTickets = await _context.Ticketing.CountAsync(t => t.TicketStatus == "Resolved"),
                    UserCount = await _context.Users.CountAsync(),
                    PendingUserApprovals = await _context.Users.CountAsync(u => u.ApprovalStatus == "Pending"),
                    SelectedTimePeriod = timePeriod,
                    TopRecurringIssues = recurringIssues.Take(5).ToList(),
                    MostCommonIssue = topIssue
                };

                return View("AdminDashboard", model);
            }

            if (User.IsInRole("Technician"))
            {
                var username = User.Identity?.Name ?? string.Empty;
                var tickets = await _context.Ticketing
                    .Where(t => t.TicketAssignedTo == username && t.TicketStatus == "In Progress")
                    .OrderByDescending(t => t.TicketPriority == "Critical")
                    .ThenByDescending(t => t.TicketPriority == "High")
                    .ThenByDescending(t => t.TicketCreated)
                    .ToListAsync();

                return View("TechnicianDashboard", tickets);
            }

            // Employee dashboard
            return View("Dashboard");
        }

        public async Task<IActionResult> MyProfile()
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userId, out var id))
                return RedirectToAction(nameof(Dashboard));

            var user = await _context.Users.FindAsync(id);
            if (user == null)
                return NotFound();

            var model = new UserProfileViewModel
            {
                UserId = user.UserId,
                UserRole = user.UserRole,
                UserDivision = user.UserDivision,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                Username = user.Username,
                UserCreated = user.UserCreated
            };

            return View(model);
        }

        public async Task<IActionResult> MyProfileEdit()
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userId, out var id))
                return RedirectToAction(nameof(Dashboard));

            var user = await _context.Users.FindAsync(id);
            if (user == null)
                return NotFound();

            return View(new UserProfileEditViewModel
            {
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber
            });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MyProfileEdit(UserProfileEditViewModel model)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (!int.TryParse(userId, out var id) || model.UserId != id)
                return RedirectToAction(nameof(Dashboard));

            var user = await _context.Users.FindAsync(model.UserId);
            if (user == null)
                return NotFound();

            model.FirstName = model.FirstName?.Trim() ?? string.Empty;
            model.LastName = model.LastName?.Trim() ?? string.Empty;
            model.Email = model.Email?.Trim() ?? string.Empty;

            if (!ModelState.IsValid)
                return View(model);

            // Check if email is already in use by another user
            if (await _context.Users.AnyAsync(u => u.UserId != model.UserId && u.Email.ToLower() == model.Email.ToLower()))
            {
                ModelState.AddModelError(nameof(model.Email), "Email is already registered.");
                return View(model);
            }

            // Update profile information
            user.FirstName = model.FirstName;
            user.LastName = model.LastName;
            user.Email = model.Email;
            user.PhoneNumber = model.PhoneNumber;

            // Update password if provided
            if (!string.IsNullOrWhiteSpace(model.NewPassword))
            {
                var passwordHasher = new Microsoft.AspNetCore.Identity.PasswordHasher<Users>();
                user.PasswordHash = passwordHasher.HashPassword(user, model.NewPassword);
            }

            try
            {
                _context.Users.Update(user);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Your profile has been updated successfully.";
                return RedirectToAction(nameof(MyProfile));
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError(string.Empty, "An error occurred while updating your profile. Please try again.");
                return View(model);
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Prototype_Capstone_2.Models;

namespace Prototype_Capstone_2.Controllers
{
    [Authorize(Roles = "Admin")]
    public class UsersController : Controller
    {
        private readonly Prototype_Capstone_2Context _context;
        private readonly PasswordHasher<Users> _passwordHasher = new();


        public UsersController(Prototype_Capstone_2Context context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var users = await _context.Users
                .OrderBy(u => u.UserRole)
                .ThenBy(u => u.LastName)
                .ThenBy(u => u.FirstName)
                .ToListAsync();
            return View(users);
        }

        public async Task<IActionResult> AdminDashboard()
        {
            var model = new UserAdminDashboardViewModel
            {
                PendingUsers = await _context.Users
                    .Where(u => u.ApprovalStatus == "Pending")
                    .OrderByDescending(u => u.UserCreated)
                    .ToListAsync(),
                ApprovedUsers = await _context.Users
                    .Where(u => u.ApprovalStatus == "Approved")
                    .OrderByDescending(u => u.UserCreated)
                    .ToListAsync()
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApproveUser(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null) return NotFound();

            if (user.ApprovalStatus == "Pending")
            {
                user.ApprovalStatus = "Approved";
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"User '{user.Username}' has been approved.";
            }

            return RedirectToAction(nameof(AdminDashboard));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RejectUser(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null) return NotFound();

            if (user.ApprovalStatus == "Pending")
            {
                user.ApprovalStatus = "Rejected";
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"User '{user.Username}' has been rejected.";
            }

            return RedirectToAction(nameof(AdminDashboard));
        }

        public IActionResult Create()
        {
            PopulateLists();
            return View(new UserCreateViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(UserCreateViewModel model)
        {
            model.Username = model.Username.Trim();
            model.Email = model.Email.Trim();
            model.FirstName = model.FirstName.Trim();
            model.LastName = model.LastName.Trim();

            ValidateRoleAndDivision(model.UserRole, model.UserDivision);

            if (await _context.Users.AnyAsync(u => u.Username.ToLower() == model.Username.ToLower()))
                ModelState.AddModelError(nameof(model.Username), "Username is already in use.");

            if (await _context.Users.AnyAsync(u => u.Email.ToLower() == model.Email.ToLower()))
                ModelState.AddModelError(nameof(model.Email), "Email is already registered.");

            if (!ModelState.IsValid)
            {
                PopulateLists();
                return View(model);
            }

            var user = new Users
            {
                UserRole = model.UserRole,
                UserDivision = model.UserDivision,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                PhoneNumber = model.PhoneNumber.Trim(),
                Username = model.Username,
                UserCreated = DateTime.UtcNow
            };
            user.PasswordHash = _passwordHasher.HashPassword(user, model.Password);

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"User '{user.Username}' created successfully.";
            return RedirectToAction(nameof(AdminDashboard));
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var user = await _context.Users.FindAsync(id);
            if (user == null) return NotFound();

            PopulateLists();
            return View(new UserEditViewModel
            {
                UserId = user.UserId,
                UserRole = user.UserRole,
                UserDivision = user.UserDivision,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email,
                PhoneNumber = user.PhoneNumber,
                Username = user.Username
            });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, UserEditViewModel model)
        {
            if (id != model.UserId) return NotFound();

            var user = await _context.Users.FindAsync(id);
            if (user == null) return NotFound();

            model.Username = model.Username.Trim();
            model.Email = model.Email.Trim();
            model.FirstName = model.FirstName.Trim();
            model.LastName = model.LastName.Trim();

            ValidateRoleAndDivision(model.UserRole, model.UserDivision);

            if (await _context.Users.AnyAsync(u => u.UserId != id && u.Username.ToLower() == model.Username.ToLower()))
                ModelState.AddModelError(nameof(model.Username), "Username is already in use.");

            if (await _context.Users.AnyAsync(u => u.UserId != id && u.Email.ToLower() == model.Email.ToLower()))
                ModelState.AddModelError(nameof(model.Email), "Email is already registered.");

            if (!string.IsNullOrWhiteSpace(model.NewPassword) && model.NewPassword != model.ConfirmNewPassword)
                ModelState.AddModelError(nameof(model.ConfirmNewPassword), "Passwords do not match.");

            if (!ModelState.IsValid)
            {
                PopulateLists();
                return View(model);
            }

            user.UserRole = model.UserRole;
            user.UserDivision = model.UserDivision;
            user.FirstName = model.FirstName;
            user.LastName = model.LastName;
            user.Email = model.Email;
            user.PhoneNumber = model.PhoneNumber.Trim();
            user.Username = model.Username;

            if (!string.IsNullOrWhiteSpace(model.NewPassword))
                user.PasswordHash = _passwordHasher.HashPassword(user, model.NewPassword);

            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = $"User '{user.Username}' updated successfully.";
            return RedirectToAction(nameof(AdminDashboard));
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();
            var user = await _context.Users.FindAsync(id);
            if (user == null) return NotFound();
            return View(user);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var currentUserId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            if (currentUserId == id.ToString())
            {
                TempData["ErrorMessage"] = "You cannot delete the account you are currently using.";
                return RedirectToAction(nameof(AdminDashboard));
            }

            var user = await _context.Users.FindAsync(id);
            if (user != null)
            {
                _context.Users.Remove(user);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"User '{user.Username}' deleted.";
            }

            return RedirectToAction(nameof(AdminDashboard));
        }

        private void ValidateRoleAndDivision(string role, string division)
        {
            var roles = new[] { "Employee", "Technician", "Admin" };
            var divisions = new[] { "Operations", "IT Operations", "Marketing", "Human Resources" };

            if (!roles.Contains(role))
                ModelState.AddModelError(nameof(UserCreateViewModel.UserRole), "Invalid user role.");

            if (!divisions.Contains(division))
                ModelState.AddModelError(nameof(UserCreateViewModel.UserDivision), "Invalid division.");
        }

        private void PopulateLists()
        {
            // Intentionally kept local to Users CRUD so this is a direct copy
            // of the same choices used by the Ticketing Division dropdown.
            ViewBag.Roles = new[] { "Employee", "Technician", "Admin" };
            ViewBag.Divisions = new[] { "Operations", "IT Operations", "Marketing", "Human Resources" };
        }
    }
}

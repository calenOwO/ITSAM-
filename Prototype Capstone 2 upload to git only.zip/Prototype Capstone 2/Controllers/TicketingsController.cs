using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using Prototype_Capstone_2.Models;

[Authorize]
public class TicketingsController : Controller
{
    private readonly Prototype_Capstone_2Context _context;

    private static readonly string[] IssueCategories =
    {
        "Software", "Hardware", "Network", "Account / Access", "Data / Application", "Other"
    };

    private static readonly string[] TicketStatuses =
    {
        "Pending", "In Progress", "Resolved"
    };

    private static readonly string[] TicketPriorities =
    {
        "Low", "Normal", "High", "Critical"
    };

    public TicketingsController(Prototype_Capstone_2Context context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index()
    {
        var currentName = User.FindFirst(System.Security.Claims.ClaimTypes.GivenName)?.Value;
        var surname = User.FindFirst(System.Security.Claims.ClaimTypes.Surname)?.Value;
        var fullName = $"{currentName} {surname}".Trim();
        var username = User.Identity?.Name ?? string.Empty;

        // Filter by full name if available, otherwise by username
        var filterName = string.IsNullOrWhiteSpace(fullName) ? username : fullName;

        var tickets = await _context.Ticketing
            .Where(t => t.TicketUserName == filterName)
            .OrderByDescending(t => t.TicketCreated)
            .ToListAsync();
        return View(tickets);
    }

    [Authorize(Roles = "Technician")]
    public async Task<IActionResult> TechnicianDashboard()
    {
        var technicianName = User.Identity?.Name ?? string.Empty;
        var assignedTickets = await _context.Ticketing
            .Where(t => t.TicketAssignedTo == technicianName && t.TicketStatus == "In Progress")
            .OrderByDescending(t => t.TicketCreated)
            .ToListAsync();

        return View(assignedTickets);
    }

    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> AdminDashboard()
    {
        var tickets = await _context.Ticketing
            .OrderByDescending(t => t.TicketCreated)
            .ToListAsync();

        ViewBag.TotalTickets = tickets.Count;
        ViewBag.PendingTickets = tickets.Count(t => t.TicketStatus == "Pending");
        ViewBag.InProgressTickets = tickets.Count(t => t.TicketStatus == "In Progress");
        ViewBag.ResolvedTickets = tickets.Count(t => t.TicketStatus == "Resolved");
        ViewBag.HighPriorityTickets = tickets.Count(t => t.TicketPriority == "High" || t.TicketPriority == "Critical");
        ViewBag.UnassignedTickets = tickets.Where(t => t.TicketStatus == "Pending").ToList();
        ViewBag.AssignedTickets = tickets.Where(t => t.TicketStatus == "In Progress").ToList();
        ViewBag.CompletedTickets = tickets.Where(t => t.TicketStatus == "Resolved").ToList();

        return View();
    }

    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> AssignTicket(int? id)
    {
        if (id == null) return NotFound();
        var ticket = await _context.Ticketing.FindAsync(id);
        if (ticket == null) return NotFound();

        await PopulateSelectListsAsync(ticket);
        return View(ticket);
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AssignTicket(int id, string assignedTo, string ticketPriority)
    {
        var ticket = await _context.Ticketing.FindAsync(id);
        if (ticket == null) return NotFound();

        if (string.IsNullOrWhiteSpace(ticketPriority) || !TicketPriorities.Contains(ticketPriority))
            ModelState.AddModelError("TicketPriority", "Please select a valid priority.");

        var technician = await _context.Users
            .FirstOrDefaultAsync(u => u.Username == assignedTo && u.UserRole == "Technician");
        if (technician == null)
            ModelState.AddModelError("TicketAssignedTo", "Please select a valid technician account.");

        if (!ModelState.IsValid)
        {
            await PopulateSelectListsAsync(ticket);
            return View(ticket);
        }

        ticket.TicketAssignedTo = technician!.Username;
        ticket.AssignedToUserId = technician.UserId;
        ticket.TicketPriority = ticketPriority;
        ticket.TicketStatus = "In Progress";

        await _context.SaveChangesAsync();
        TempData["SuccessMessage"] = $"Ticket #{ticket.TicketId:D5} assigned to {technician.FullName}.";
        return RedirectToAction(nameof(AdminDashboard));
    }

    // Kept as a safe compatibility endpoint for old bookmarks/links.
    [Authorize(Roles = "Admin")]
    public IActionResult RejectTicket(int? id)
    {
        TempData["ErrorMessage"] = "Admins cannot resolve or reject tickets. Assign the ticket to a technician instead.";
        return RedirectToAction(nameof(AdminDashboard));
    }

    [Authorize(Roles = "Technician")]
    public async Task<IActionResult> ResolveTicket(int? id)
    {
        if (id == null) return NotFound();
        var ticket = await _context.Ticketing.FindAsync(id);
        if (ticket == null) return NotFound();

        if (ticket.TicketStatus != "In Progress" || ticket.TicketAssignedTo != (User.Identity?.Name ?? string.Empty))
            return Forbid();

        return View(ticket);
    }

    [HttpPost]
    [Authorize(Roles = "Technician")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> ResolveTicket(int id, string resolution)
    {
        var ticket = await _context.Ticketing.FindAsync(id);
        if (ticket == null) return NotFound();

        var technicianName = User.Identity?.Name ?? string.Empty;
        if (ticket.TicketStatus != "In Progress" || ticket.TicketAssignedTo != technicianName)
            return Forbid();

        if (string.IsNullOrWhiteSpace(resolution))
        {
            ModelState.AddModelError("TicketResolution", "Resolution details are required");
            return View(ticket);
        }

        ticket.TicketResolution = resolution.Trim();
        ticket.TicketStatus = "Resolved";
        ticket.TicketTimeFixed = DateTime.UtcNow;

        await _context.SaveChangesAsync();
        TempData["SuccessMessage"] = $"Ticket #{ticket.TicketId:D5} was resolved.";
        return RedirectToAction("TechnicianDashboard", "Home");
    }

    public async Task<IActionResult> Details(int? id)
    {
        if (id == null) return NotFound();
        var ticket = await _context.Ticketing.FirstOrDefaultAsync(t => t.TicketId == id);
        if (ticket == null) return NotFound();
        return View(ticket);
    }

    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> AssignedDetails(int? id)
    {
        if (id == null) return NotFound();
        var ticket = await _context.Ticketing.FirstOrDefaultAsync(t => t.TicketId == id);
        if (ticket == null) return NotFound();

        if (ticket.TicketStatus != "In Progress")
        {
            TempData["ErrorMessage"] = "This ticket is not currently assigned.";
            return RedirectToAction(nameof(AdminDashboard));
        }

        await PopulateSelectListsAsync(ticket);
        return View(ticket);
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AssignedDetails(int id, string assignedTo)
    {
        var ticket = await _context.Ticketing.FindAsync(id);
        if (ticket == null) return NotFound();

        if (ticket.TicketStatus != "In Progress")
            return RedirectToAction(nameof(AdminDashboard));

        var technician = await _context.Users
            .FirstOrDefaultAsync(u => u.Username == assignedTo && u.UserRole == "Technician");
        if (technician == null)
        {
            ModelState.AddModelError("TicketAssignedTo", "Please select a valid technician account.");
            await PopulateSelectListsAsync(ticket);
            return View(ticket);
        }

        ticket.TicketAssignedTo = technician.Username;
        ticket.AssignedToUserId = technician.UserId;
        await _context.SaveChangesAsync();
        TempData["SuccessMessage"] = "Assigned technician updated successfully.";
        return RedirectToAction(nameof(AdminDashboard));
    }

    public IActionResult Create()
    {
        var currentName = User.FindFirst(System.Security.Claims.ClaimTypes.GivenName)?.Value;
        var surname = User.FindFirst(System.Security.Claims.ClaimTypes.Surname)?.Value;
        var fullName = $"{currentName} {surname}".Trim();
        var currentUser = _context.Users.AsNoTracking().FirstOrDefault(u => u.Username == User.Identity!.Name);
        var division = currentUser?.UserDivision ?? string.Empty;

        var ticket = new Ticketing
        {
            TicketUserName = string.IsNullOrWhiteSpace(fullName) ? User.Identity?.Name ?? string.Empty : fullName,
            SubmittedByUserId = currentUser?.UserId,
            TicketDivision = division,
            TicketDateCreated = DateTime.Today,
            TicketStatus = "Pending",
            TicketPriority = "Normal",
            TicketAssignedTo = string.Empty
        };

        PopulateSelectLists(ticket);
        return View(ticket);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Ticketing ticket)
    {
        NormalizeTicket(ticket);

        if (ModelState.IsValid)
        {
            var currentUser = await _context.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Username == User.Identity!.Name);

            ticket.SubmittedByUserId = currentUser?.UserId;
            ticket.TicketCreated = DateTime.UtcNow;
            ticket.TicketDateCreated = DateTime.Today;
            ticket.TicketStatus = "Pending";
            ticket.TicketPriority = string.IsNullOrWhiteSpace(ticket.TicketPriority) ? "Normal" : ticket.TicketPriority;
            ticket.TicketAssignedTo = string.Empty;
            _context.Ticketing.Add(ticket);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        PopulateSelectLists(ticket);
        return View(ticket);
    }

    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null) return NotFound();
        var ticket = await _context.Ticketing.FindAsync(id);
        if (ticket == null) return NotFound();

        if (ticket.TicketStatus != "Pending")
        {
            TempData["ErrorMessage"] = "Tickets can only be edited while in Pending status.";
            return RedirectToAction(nameof(Index));
        }

        PopulateSelectLists(ticket);
        return View(ticket);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Ticketing ticket)
    {
        if (id != ticket.TicketId) return NotFound();
        var existing = await _context.Ticketing.FindAsync(id);
        if (existing == null) return NotFound();

        if (existing.TicketStatus != "Pending")
        {
            TempData["ErrorMessage"] = "Tickets can only be edited while in Pending status.";
            return RedirectToAction(nameof(Index));
        }

        NormalizeTicket(ticket);
        if (ModelState.IsValid)
        {
            existing.TicketUserName = ticket.TicketUserName;
            existing.TicketDivision = ticket.TicketDivision;
            existing.TicketIssueCategory = ticket.TicketIssueCategory;
            existing.TicketDescription = ticket.TicketDescription;
            existing.TicketPriority = ticket.TicketPriority;
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        PopulateSelectLists(ticket);
        return View(ticket);
    }

    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null) return NotFound();
        var ticket = await _context.Ticketing.FirstOrDefaultAsync(t => t.TicketId == id);
        if (ticket == null) return NotFound();
        return View(ticket);
    }

    [HttpPost, ActionName("Delete")]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var ticket = await _context.Ticketing.FindAsync(id);
        if (ticket != null)
        {
            _context.Ticketing.Remove(ticket);
            await _context.SaveChangesAsync();
        }
        return RedirectToAction(nameof(AdminDashboard));
    }

    private async Task PopulateSelectListsAsync(Ticketing ticket)
    {
        PopulateSelectLists(ticket);

        // Get technicians who have "In Progress" tickets
        var busyTechnicians = await _context.Ticketing
            .AsNoTracking()
            .Where(t => t.TicketStatus == "In Progress" && !string.IsNullOrEmpty(t.TicketAssignedTo))
            .Select(t => t.TicketAssignedTo)
            .Distinct()
            .ToListAsync();

        // Get all technicians who are NOT busy, or who are currently assigned to this ticket
        var technicians = await _context.Users
            .AsNoTracking()
            .Where(u => u.UserRole == "Technician" && 
                   (!busyTechnicians.Contains(u.Username) || u.Username == ticket.TicketAssignedTo))
            .OrderBy(u => u.LastName)
            .ThenBy(u => u.FirstName)
            .Select(u => new { u.Username, Name = u.FirstName + " " + u.LastName })
            .ToListAsync();

        ViewBag.Technicians = new SelectList(technicians, "Username", "Name", ticket.TicketAssignedTo);
    }

    private void PopulateSelectLists(Ticketing ticket)
    {
        ViewBag.Divisions = new SelectList(new[] { "Operations", "IT Operations", "Marketing", "Human Resources" }, ticket.TicketDivision);
        ViewBag.IssueCategories = new SelectList(IssueCategories, ticket.TicketIssueCategory);
        ViewBag.TicketStatuses = new SelectList(TicketStatuses, ticket.TicketStatus);
        ViewBag.TicketPriorities = new SelectList(TicketPriorities, ticket.TicketPriority);
    }

    private static void NormalizeTicket(Ticketing ticket)
    {
        ticket.TicketUserName = ticket.TicketUserName?.Trim() ?? string.Empty;
        ticket.TicketDivision = ticket.TicketDivision?.Trim() ?? string.Empty;
        ticket.TicketIssueCategory = ticket.TicketIssueCategory?.Trim() ?? string.Empty;
        ticket.TicketPersonNotified = ticket.TicketPersonNotified?.Trim() ?? string.Empty;
        ticket.TicketDescription = ticket.TicketDescription?.Trim() ?? string.Empty;
        ticket.TicketResolution = ticket.TicketResolution?.Trim() ?? string.Empty;
        ticket.TicketAssignedTo = ticket.TicketAssignedTo?.Trim() ?? string.Empty;
    }
}

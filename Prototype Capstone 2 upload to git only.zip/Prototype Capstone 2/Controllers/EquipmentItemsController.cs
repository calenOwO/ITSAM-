using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Prototype_Capstone_2.Models;

public class EquipmentItemController : Controller
{
    private readonly Prototype_Capstone_2Context _context;

    public EquipmentItemController(Prototype_Capstone_2Context context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index()
    {
        return View(await _context.EquipmentItem
            .Include(e => e.Equipment)
            .ToListAsync());
    }

    public async Task<IActionResult> Details(int? id)
    {
        if (id == null) return NotFound();

        var equipmentitem = await _context.EquipmentItem
            .Include(e => e.Equipment)
            .FirstOrDefaultAsync(m => m.ItemID == id);

        return equipmentitem == null ? NotFound() : View(equipmentitem);
    }

    public IActionResult Create(int? equipmentId)
    {
        PopulateEquipmentDropdown();
        return View(new EquipmentItem { EquipmentID = equipmentId ?? 0 });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("EquipmentID,ItemLabel,Status")] EquipmentItem equipmentitem)
    {
        ModelState.Remove("Equipment");

        var equipmentExists = await _context.Equipment.AnyAsync(e => e.EquipmentID == equipmentitem.EquipmentID);
        if (!equipmentExists)
            ModelState.AddModelError("EquipmentID", "The selected equipment does not exist.");

        if (ModelState.IsValid)
        {
            _context.Add(equipmentitem);
            await _context.SaveChangesAsync();
            await UpdateEquipmentQuantities(equipmentitem.EquipmentID);
            return RedirectToAction("Index", "Equipment");
        }

        PopulateEquipmentDropdown();
        return View(equipmentitem);
    }

    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null) return NotFound();

        var equipmentitem = await _context.EquipmentItem.FindAsync(id);
        return equipmentitem == null ? NotFound() : View(equipmentitem);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int? id, [Bind("ItemID,EquipmentID,ItemLabel,Status")] EquipmentItem submitted)
    {
        if (id == null || id != submitted.ItemID)
            return NotFound();

        var existing = await _context.EquipmentItem.FindAsync(id);
        if (existing == null)
            return NotFound();

        ModelState.Remove("Equipment");

        var equipmentExists = await _context.Equipment.AnyAsync(e => e.EquipmentID == submitted.EquipmentID);
        if (!equipmentExists)
            ModelState.AddModelError("EquipmentID", "The selected equipment does not exist.");

        // Never allow an admin to make a borrowed item appear available/inactive manually.
        var activeBorrowing = await _context.BorrowingEquipmentItem
            .AnyAsync(bei => bei.EquipmentItemID == existing.ItemID && bei.Status != "Returned" && bei.Status != "Completed");

        if (activeBorrowing && !string.Equals(existing.Status, submitted.Status, StringComparison.OrdinalIgnoreCase))
        {
            ModelState.AddModelError("Status", "This equipment item is assigned to an active borrowing and its status cannot be changed manually.");
        }

        if (ModelState.IsValid)
        {
            var oldEquipmentId = existing.EquipmentID;
            existing.EquipmentID = submitted.EquipmentID;
            existing.ItemLabel = submitted.ItemLabel.Trim();
            existing.Status = submitted.Status;

            await _context.SaveChangesAsync();

            await UpdateEquipmentQuantities(oldEquipmentId);
            if (oldEquipmentId != submitted.EquipmentID)
                await UpdateEquipmentQuantities(submitted.EquipmentID);

            return RedirectToAction("Index", "Equipment");
        }

        return View(submitted);
    }

    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null) return NotFound();

        var equipmentitem = await _context.EquipmentItem
            .Include(e => e.Equipment)
            .FirstOrDefaultAsync(m => m.ItemID == id);

        return equipmentitem == null ? NotFound() : View(equipmentitem);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int? id)
    {
        if (id == null) return NotFound();

        var equipmentitem = await _context.EquipmentItem.FindAsync(id);
        if (equipmentitem == null)
            return NotFound();

        var hasBorrowingHistory = await _context.BorrowingEquipmentItem
            .AnyAsync(bei => bei.EquipmentItemID == equipmentitem.ItemID);

        if (hasBorrowingHistory)
        {
            TempData["Error"] = "This equipment item cannot be deleted because it has borrowing history. Mark it as Inactive instead.";
            return RedirectToAction(nameof(Details), new { id });
        }

        var equipmentId = equipmentitem.EquipmentID;
        _context.EquipmentItem.Remove(equipmentitem);
        await _context.SaveChangesAsync();
        await UpdateEquipmentQuantities(equipmentId);

        return RedirectToAction("Index", "Equipment");
    }

    private async Task UpdateEquipmentQuantities(int equipmentId)
    {
        var equipment = await _context.Equipment.FindAsync(equipmentId);
        if (equipment == null) return;

        equipment.EquipmentQuantity = await _context.EquipmentItem
            .CountAsync(ei => ei.EquipmentID == equipmentId);

        equipment.EquipmentAvailableQuantity = await _context.EquipmentItem
            .CountAsync(ei => ei.EquipmentID == equipmentId && ei.Status == "Available");

        await _context.SaveChangesAsync();
    }

    private void PopulateEquipmentDropdown()
    {
        ViewBag.Equipment = _context.Equipment
            .OrderBy(e => e.EquipmentName)
            .Select(e => new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
            {
                Value = e.EquipmentID.ToString(),
                Text = e.EquipmentName
            })
            .ToList();
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using Prototype_Capstone_2.Models;

public class BorrowingsController : Controller
{
    private readonly Prototype_Capstone_2Context _context;

    public BorrowingsController(Prototype_Capstone_2Context context)
    {
        _context = context;
    }

    // GET: BORROWINGS
    public async Task<IActionResult> Index()
    {
        var currentName = User.FindFirst(System.Security.Claims.ClaimTypes.GivenName)?.Value;
        var surname = User.FindFirst(System.Security.Claims.ClaimTypes.Surname)?.Value;
        var fullName = $"{currentName} {surname}".Trim();
        var username = User.Identity?.Name ?? string.Empty;

        // Filter by full name if available, otherwise by username
        var filterName = string.IsNullOrWhiteSpace(fullName) ? username : fullName;

        var requests = await _context.BorrowingRequests
            .Where(r => r.BorrowerName == filterName)
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.Equipment)
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.AssignedItems)
                    .ThenInclude(ai => ai.EquipmentItem)
            .OrderByDescending(r => r.RequestId)
            .ToListAsync();

        foreach (var req in requests)
            await SyncRequestStatusAsync(req.RequestId);

        await _context.SaveChangesAsync();

        return View(requests);
    }

    // GET: BORROWINGS/Create
    public async Task<IActionResult> Create()
    {
        return View(await BuildCreateViewModelAsync());
    }

    // POST: BORROWINGS/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(CreateBorrowingViewModel viewModel)
    {
        ValidateCreateModel(viewModel);

        if (ModelState.IsValid)
        {
            await using var transaction = await _context.Database.BeginTransactionAsync(IsolationLevel.Serializable);

            try
            {
                var requestedQuantities = viewModel.SelectedEquipmentIds
                    .Select((equipmentId, index) => new { EquipmentId = equipmentId, Quantity = viewModel.SelectedQuantities[index] })
                    .GroupBy(x => x.EquipmentId)
                    .ToDictionary(g => g.Key, g => g.Sum(x => x.Quantity));

                var equipmentIds = requestedQuantities.Keys.ToList();
                var equipment = await _context.Equipment
                    .Where(e => equipmentIds.Contains(e.EquipmentID))
                    .ToDictionaryAsync(e => e.EquipmentID);

                foreach (var requested in requestedQuantities)
                {
                    if (!equipment.TryGetValue(requested.Key, out var selectedEquipment))
                    {
                        ModelState.AddModelError("SelectedEquipmentIds", $"Equipment with ID {requested.Key} does not exist.");
                        continue;
                    }

                    if (selectedEquipment.EquipmentAvailableQuantity < requested.Value)
                    {
                        ModelState.AddModelError("SelectedEquipmentIds",
                            $"Only {selectedEquipment.EquipmentAvailableQuantity} {selectedEquipment.EquipmentName} currently available. Requested: {requested.Value}.");
                    }
                }

                if (!ModelState.IsValid)
                {
                    await transaction.RollbackAsync();
                }
                else
                {
                    var borrowDateUtc = ToUtc(viewModel.BorrowDate);
                    var currentUser = await _context.Users.AsNoTracking()
                        .FirstOrDefaultAsync(u => u.Username == User.Identity!.Name);

                    var request = new BorrowingRequests
                    {
                        BorrowerName = viewModel.BorrowerName.Trim(),
                        RequesterUserId = currentUser?.UserId,
                        BorrowerDivision = viewModel.BorrowerDivision,
                        BorrowDate = borrowDateUtc,
                        ReturnDate = null,
                        Status = "Pending"
                    };

                    _context.BorrowingRequests.Add(request);
                    await _context.SaveChangesAsync();

                    // One Borrowing row per equipment type, carrying the total Quantity requested.
                    foreach (var requested in requestedQuantities)
                    {
                        request.Borrowings.Add(new Borrowing
                        {
                            BorrowerName = request.BorrowerName,
                            EquipmentID = requested.Key,
                            Quantity = requested.Value,
                            BorrowDate = borrowDateUtc,
                            ReturnDate = null,
                            Status = "Pending"
                        });
                    }

                    await _context.SaveChangesAsync();
                    await transaction.CommitAsync();
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (DbUpdateException dbEx)
            {
                await transaction.RollbackAsync();
                ModelState.AddModelError("", GetDatabaseError(dbEx));
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                ModelState.AddModelError("", $"An unexpected error occurred: {ex.Message}");
            }
        }

        viewModel.EquipmentList = await GetBorrowableEquipmentAsync(viewModel.SelectedEquipmentIds);
        return View(viewModel);
    }

    // GET: BORROWINGS/EditRequest/5
    [Authorize(Roles = "Admin,Technician")]
    public async Task<IActionResult> EditRequest(int? requestid)
    {
        if (requestid == null)
            return NotFound();

        var request = await _context.BorrowingRequests
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.Equipment)
            .FirstOrDefaultAsync(r => r.RequestId == requestid);

        if (request == null)
            return NotFound();

        // Only allow editing pending requests
        if (request.Status != "Pending")
        {
            TempData["Error"] = "Only pending requests can be edited.";
            return RedirectToAction(nameof(Index));
        }

        var borrowings = request.Borrowings.OrderBy(b => b.BorrowingId).ToList();
        var equipmentList = await GetBorrowableEquipmentAsync(borrowings.Select(b => b.EquipmentID));

        var viewModel = new CreateBorrowingViewModel
        {
            BorrowerName = request.BorrowerName,
            BorrowDate = request.BorrowDate,
            SelectedEquipmentIds = borrowings.Select(b => b.EquipmentID).ToList(),
            SelectedQuantities = borrowings.Select(b => b.Quantity).ToList(),
            EquipmentList = equipmentList
        };

        ViewData["RequestId"] = requestid;
        return View(viewModel);
    }

    // POST: BORROWINGS/EditRequest/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = "Admin,Technician")]
    public async Task<IActionResult> EditRequest(int? requestid, CreateBorrowingViewModel viewModel)
    {
        if (requestid == null)
            return NotFound();

        var request = await _context.BorrowingRequests
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.Equipment)
            .FirstOrDefaultAsync(r => r.RequestId == requestid);

        if (request == null)
            return NotFound();

        // Only allow editing pending requests
        if (request.Status != "Pending")
        {
            TempData["Error"] = "Only pending requests can be edited.";
            return RedirectToAction(nameof(Index));
        }

        ValidateCreateModel(viewModel);

        if (ModelState.IsValid)
        {
            await using var transaction = await _context.Database.BeginTransactionAsync(IsolationLevel.Serializable);

            try
            {
                var requestedQuantities = viewModel.SelectedEquipmentIds
                    .Select((equipmentId, index) => new { EquipmentId = equipmentId, Quantity = viewModel.SelectedQuantities[index] })
                    .GroupBy(x => x.EquipmentId)
                    .ToDictionary(g => g.Key, g => g.Sum(x => x.Quantity));

                var equipmentIds = requestedQuantities.Keys.ToList();
                var equipment = await _context.Equipment
                    .Where(e => equipmentIds.Contains(e.EquipmentID))
                    .ToDictionaryAsync(e => e.EquipmentID);

                // Validate equipment availability. Since each Borrowing row now carries
                // a Quantity, "currently borrowed" is a sum of Quantity, not a row count.
                var currentBorrowedEquipment = request.Borrowings
                    .GroupBy(b => b.EquipmentID)
                    .ToDictionary(g => g.Key, g => g.Sum(b => b.Quantity));

                foreach (var requested in requestedQuantities)
                {
                    if (!equipment.TryGetValue(requested.Key, out var selectedEquipment))
                    {
                        ModelState.AddModelError("SelectedEquipmentIds", $"Equipment with ID {requested.Key} does not exist.");
                        continue;
                    }

                    var currentBorrowed = currentBorrowedEquipment.ContainsKey(requested.Key)
                        ? currentBorrowedEquipment[requested.Key]
                        : 0;

                    var newQuantity = requested.Value;
                    var availableForNewRequests = selectedEquipment.EquipmentAvailableQuantity + currentBorrowed;

                    if (availableForNewRequests < newQuantity)
                    {
                        ModelState.AddModelError("SelectedEquipmentIds",
                            $"Only {availableForNewRequests} of {selectedEquipment.EquipmentName} available (including current borrowed items), but you requested {newQuantity}.");
                    }
                }

                if (!ModelState.IsValid)
                {
                    await transaction.RollbackAsync();
                }
                else
                {
                    // Update request details
                    request.BorrowerName = viewModel.BorrowerName.Trim();
                    request.BorrowDate = ToUtc(viewModel.BorrowDate);

                    // Remove all existing borrowings (pending requests have no AssignedItems yet)
                    _context.Borrowing.RemoveRange(request.Borrowings);
                    await _context.SaveChangesAsync();

                    // Add new borrowings, one row per equipment type
                    foreach (var requested in requestedQuantities)
                    {
                        request.Borrowings.Add(new Borrowing
                        {
                            BorrowerName = request.BorrowerName,
                            EquipmentID = requested.Key,
                            Quantity = requested.Value,
                            BorrowDate = request.BorrowDate,
                            ReturnDate = null,
                            Status = "Pending"
                        });
                    }

                    await _context.SaveChangesAsync();
                    await transaction.CommitAsync();

                    TempData["Success"] = "Borrowing request updated successfully!";
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (DbUpdateException dbEx)
            {
                await transaction.RollbackAsync();
                ModelState.AddModelError("", GetDatabaseError(dbEx));
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                ModelState.AddModelError("", $"An unexpected error occurred: {ex.Message}");
            }
        }

        viewModel.EquipmentList = await GetBorrowableEquipmentAsync(
            (viewModel.SelectedEquipmentIds ?? new List<int>()).Concat(request.Borrowings.Select(b => b.EquipmentID)));
        ViewData["RequestId"] = requestid;
        return View(viewModel);
    }

    // GET: BORROWINGS/DeleteRequest/5
    [Authorize(Roles = "Admin,Technician")]
    public async Task<IActionResult> DeleteRequest(int? requestid)
    {
        if (requestid == null)
            return NotFound();

        var request = await _context.BorrowingRequests
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.Equipment)
            .FirstOrDefaultAsync(r => r.RequestId == requestid);

        if (request == null)
            return NotFound();

        // Check if request can be deleted (only Pending and Rejected requests can be deleted)
        if (request.Status == "Confirmed" || request.Status == "Completed")
        {
            TempData["ErrorMessage"] = $"Cannot delete a {request.Status.ToLower()} borrowing request. Only Pending requests can be deleted.";
            return RedirectToAction(nameof(AdminDashboard));
        }

        return View(request);
    }

    // POST: BORROWINGS/DeleteRequest/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = "Admin,Technician")]
    public async Task<IActionResult> DeleteRequestConfirmed(int? requestid, string? remarks)
    {
        if (requestid == null)
            return NotFound();

        await using var transaction = await _context.Database.BeginTransactionAsync(IsolationLevel.Serializable);
        try
        {
            var request = await _context.BorrowingRequests
                .Include(r => r.Borrowings)
                    .ThenInclude(b => b.AssignedItems)
                        .ThenInclude(ai => ai.EquipmentItem)
                .Include(r => r.Borrowings)
                    .ThenInclude(b => b.Equipment)
                .FirstOrDefaultAsync(r => r.RequestId == requestid);

            if (request == null)
                return NotFound();

            // Check if request can be deleted (only Pending and Rejected requests can be deleted)
            if (request.Status == "Confirmed" || request.Status == "Completed")
            {
                await transaction.RollbackAsync();
                TempData["ErrorMessage"] = $"Cannot delete a {request.Status.ToLower()} borrowing request. Only Pending requests can be deleted.";
                return RedirectToAction(nameof(AdminDashboard));
            }

            // Mark the entire request as Rejected with remarks
            request.Status = "Rejected";
            request.Remarks = remarks ?? "No remarks provided";

            // Mark all borrowing items as Rejected
            foreach (var borrowing in request.Borrowings)
            {
                borrowing.Status = "Rejected";

                // Return any in-use equipment
                foreach (var assigned in borrowing.AssignedItems)
                {
                    if (assigned.Status == "In-Use" && assigned.EquipmentItem != null)
                        assigned.EquipmentItem.Status = "Available";
                }
            }

            var equipmentIds = request.Borrowings.Select(b => b.EquipmentID).Distinct().ToList();
            await _context.SaveChangesAsync();

            foreach (var equipmentId in equipmentIds)
                await RecalculateEquipmentAvailabilityAsync(equipmentId);

            await _context.SaveChangesAsync();
            await transaction.CommitAsync();

            return RedirectToAction(nameof(ViewRequestAdmin), new { requestid });
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            TempData["ErrorMessage"] = $"Unable to reject the request: {ex.Message}";
            return RedirectToAction(nameof(ViewRequest), new { requestid });
        }
    }

    // GET: BORROWINGS/Delete/5 - reject pending line item
    public async Task<IActionResult> Delete(int? borrowingid)
    {
        if (borrowingid == null)
            return NotFound();

        var borrowing = await _context.Borrowing
            .Include(b => b.Equipment)
            .FirstOrDefaultAsync(b => b.BorrowingId == borrowingid);

        return borrowing == null ? NotFound() : View(borrowing);
    }

    // POST: BORROWINGS/Delete/5 - reject pending line item
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int? borrowingid, string? remarks)
    {
        if (borrowingid == null)
            return NotFound();

        var borrowing = await _context.Borrowing
            .Include(b => b.AssignedItems)
                .ThenInclude(ai => ai.EquipmentItem)
            .Include(b => b.Equipment)
            .Include(b => b.BorrowingRequest)
            .FirstOrDefaultAsync(b => b.BorrowingId == borrowingid);

        if (borrowing == null)
            return NotFound();

        var requestId = borrowing.RequestId;
        var equipmentId = borrowing.EquipmentID;

        // Mark the borrowing as "Rejected" instead of deleting it
        borrowing.Status = "Rejected";

        // Update the request with rejection remarks and status
        var request = borrowing.BorrowingRequest;
        if (request != null)
        {
            request.Status = "Rejected";
            request.Remarks = remarks ?? "No remarks provided";
        }

        // Return equipment to available if it was in-use
        foreach (var assigned in borrowing.AssignedItems)
        {
            if (assigned.Status == "In-Use" && assigned.EquipmentItem != null)
                assigned.EquipmentItem.Status = "Available";
        }

        // Save changes instead of deleting
        await _context.SaveChangesAsync();
        await RecalculateEquipmentAvailabilityAsync(equipmentId);
        await SyncRequestStatusAsync(requestId);
        await _context.SaveChangesAsync();

        return RedirectToAction(nameof(ViewRequestAdmin), new { requestid = requestId });
    }

    // GET: BORROWINGS/AdminDashboard
    [Authorize(Roles = "Admin,Technician")]
    public async Task<IActionResult> AdminDashboard()
    {
        var requests = await _context.BorrowingRequests
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.Equipment)
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.AssignedItems)
                    .ThenInclude(ai => ai.EquipmentItem)
            .OrderByDescending(r => r.RequestId)
            .ToListAsync();

        foreach (var request in requests)
            await SyncRequestStatusAsync(request.RequestId);

        await _context.SaveChangesAsync();
        return View(requests);
    }

    // GET: BORROWINGS/Accept/5
    [Authorize(Roles = "Admin,Technician")]
    public async Task<IActionResult> Accept(int? requestid)
    {
        if (requestid == null)
            return NotFound();

        var request = await _context.BorrowingRequests
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.Equipment)
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.AssignedItems)
                    .ThenInclude(ai => ai.EquipmentItem)
            .FirstOrDefaultAsync(r => r.RequestId == requestid);

        if (request == null)
            return NotFound();

        if (request.Status != "Pending" || request.Borrowings.Any(b => b.Status != "Pending"))
        {
            TempData["Error"] = "Only pending requests can be accepted.";
            return RedirectToAction(nameof(ViewRequestAdmin), new { requestid });
        }

        // For each line, offer up to Quantity available items to choose from.
        var equipmentItemLists = new Dictionary<int, List<EquipmentItem>>();
        foreach (var borrowing in request.Borrowings)
        {
            equipmentItemLists[borrowing.BorrowingId] = await GetAvailableEquipmentItemsAsync(borrowing.EquipmentID);
        }

        ViewData["EquipmentItemLists"] = equipmentItemLists;
        return View(request.Borrowings);
    }

    // POST: BORROWINGS/AcceptRequest
    // borrowingIds[i] / equipmentItemIds[i] are parallel arrays: each pair assigns
    // one physical EquipmentItem to one unit of the given Borrowing line. A line
    // with Quantity = 3 must appear 3 times in borrowingIds (once per unit).
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> AcceptRequest(int? requestId, int[] borrowingIds, int[] equipmentItemIds)
    {
        if (requestId == null)
            return NotFound();

        var request = await _context.BorrowingRequests
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.Equipment)
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.AssignedItems)
            .FirstOrDefaultAsync(r => r.RequestId == requestId);

        if (request == null)
            return NotFound();

        if (request.Status != "Pending" || request.Borrowings.Any(b => b.Status != "Pending"))
        {
            TempData["Error"] = "Only pending requests can be accepted.";
            return RedirectToAction(nameof(ViewRequestAdmin), new { requestid = requestId });
        }

        // Validate input
        if (borrowingIds == null || equipmentItemIds == null || borrowingIds.Length == 0)
        {
            TempData["Error"] = "You must select items for all borrowings.";
            return RedirectToAction(nameof(Accept), new { requestid = requestId });
        }

        if (borrowingIds.Length != equipmentItemIds.Length)
        {
            TempData["Error"] = "Malformed selection submitted.";
            return RedirectToAction(nameof(Accept), new { requestid = requestId });
        }

        var borrowingsList = request.Borrowings.OrderBy(b => b.BorrowingId).ToList();
        var selectionsByBorrowing = borrowingIds
            .Select((borrowingId, index) => new { BorrowingId = borrowingId, EquipmentItemId = equipmentItemIds[index] })
            .GroupBy(x => x.BorrowingId)
            .ToDictionary(g => g.Key, g => g.Select(x => x.EquipmentItemId).ToList());

        // Every line must have exactly Quantity selections, each with a real item chosen.
        foreach (var borrowing in borrowingsList)
        {
            if (!selectionsByBorrowing.TryGetValue(borrowing.BorrowingId, out var selections) ||
                selections.Count != borrowing.Quantity ||
                selections.Any(id => id <= 0))
            {
                TempData["Error"] = $"Please select {borrowing.Quantity} item(s) for {borrowing.Equipment?.EquipmentName}.";
                return RedirectToAction(nameof(Accept), new { requestid = requestId });
            }
        }

        // No item can be used twice, whether within one line or across lines.
        var allSelectedItemIds = selectionsByBorrowing.Values.SelectMany(x => x).ToList();
        if (allSelectedItemIds.Count != allSelectedItemIds.Distinct().Count())
        {
            TempData["Error"] = "The same item cannot be assigned more than once.";
            return RedirectToAction(nameof(Accept), new { requestid = requestId });
        }

        await using var transaction = await _context.Database.BeginTransactionAsync(IsolationLevel.Serializable);
        try
        {
            var selectedItems = await _context.EquipmentItem
                .Where(ei => allSelectedItemIds.Contains(ei.ItemID))
                .ToListAsync();

            var duplicateLabels = selectedItems
                .GroupBy(ei => ei.ItemLabel)
                .Where(g => g.Count() > 1)
                .Select(g => g.Key)
                .ToList();

            if (duplicateLabels.Any())
            {
                await transaction.RollbackAsync();
                TempData["Error"] = $"Cannot use the same item label multiple times: {string.Join(", ", duplicateLabels)}";
                return RedirectToAction(nameof(Accept), new { requestid = requestId });
            }

            foreach (var borrowing in borrowingsList)
            {
                foreach (var itemId in selectionsByBorrowing[borrowing.BorrowingId])
                {
                    var item = selectedItems.FirstOrDefault(ei => ei.ItemID == itemId);

                    if (item == null)
                        throw new InvalidOperationException($"Selected item {itemId} not found.");

                    if (item.EquipmentID != borrowing.EquipmentID)
                        throw new InvalidOperationException($"Selected item does not match equipment type.");

                    if (item.Status != "Available")
                        throw new InvalidOperationException($"Item '{item.ItemLabel}' is no longer available.");

                    borrowing.AssignedItems.Add(new BorrowingEquipmentItem
                    {
                        EquipmentItemID = item.ItemID,
                        Status = "In-Use"
                    });
                    item.Status = "Borrowed";
                }

                borrowing.Status = CalculateBorrowingStatus(borrowing.AssignedItems);
            }

            // Update request status
            request.Status = CalculateRequestStatus(request.Borrowings);

            await _context.SaveChangesAsync();

            // Recalculate equipment availability
            var equipmentIds = request.Borrowings.Select(b => b.EquipmentID).Distinct().ToList();
            foreach (var equipmentId in equipmentIds)
                await RecalculateEquipmentAvailabilityAsync(equipmentId);

            await _context.SaveChangesAsync();
            await transaction.CommitAsync();

            TempData["Success"] = "All borrowing items accepted successfully!";
            return RedirectToAction(nameof(AdminDashboard));
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            TempData["Error"] = $"Error accepting request: {ex.Message}";
            return RedirectToAction(nameof(Accept), new { requestid = requestId });
        }
    }

    // GET: BORROWINGS/InspectRequest/5
    // Lists every "In-Use" unit on the request so the admin can inspect and return them all at once.
    [Authorize(Roles = "Admin,Technician")]
    public async Task<IActionResult> InspectRequest(int? requestid)
    {
        if (requestid == null)
            return NotFound();

        var request = await _context.BorrowingRequests
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.Equipment)
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.AssignedItems)
                    .ThenInclude(ai => ai.EquipmentItem)
            .FirstOrDefaultAsync(r => r.RequestId == requestid);

        if (request == null)
            return NotFound();

        var inUseUnits = request.Borrowings
            .SelectMany(b => b.AssignedItems)
            .Where(ai => ai.Status == "In-Use")
            .ToList();

        if (!inUseUnits.Any())
        {
            TempData["Error"] = "There are no items awaiting inspection in this request.";
            return RedirectToAction(nameof(AdminDashboard));
        }

        ViewData["RequestId"] = requestid;
        return View(inUseUnits);
    }

    // POST: BORROWINGS/InspectRequest
    // borrowingEquipmentItemIds[i] / inspectionResults[i] are parallel arrays, one per unit.
    // Inspecting a unit here both records its condition and marks it returned in a single step.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> InspectRequest(int? requestId, int[] borrowingEquipmentItemIds, string[] inspectionResults)
    {
        if (requestId == null)
            return NotFound();

        var request = await _context.BorrowingRequests
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.AssignedItems)
                    .ThenInclude(ai => ai.EquipmentItem)
            .FirstOrDefaultAsync(r => r.RequestId == requestId);

        if (request == null)
            return NotFound();

        var inUseUnits = request.Borrowings
            .SelectMany(b => b.AssignedItems)
            .Where(ai => ai.Status == "In-Use")
            .ToList();

        if (!inUseUnits.Any())
        {
            TempData["Error"] = "There are no items awaiting inspection in this request.";
            return RedirectToAction(nameof(AdminDashboard));
        }

        if (borrowingEquipmentItemIds == null || inspectionResults == null || inspectionResults.Length == 0)
        {
            TempData["Error"] = "You must select a condition for all items.";
            return RedirectToAction(nameof(InspectRequest), new { requestid = requestId });
        }

        if (borrowingEquipmentItemIds.Length != inUseUnits.Count || inspectionResults.Length != inUseUnits.Count)
        {
            TempData["Error"] = "Please provide inspection results for all items.";
            return RedirectToAction(nameof(InspectRequest), new { requestid = requestId });
        }

        var validResults = new[] { "Returned", "Damaged", "Lost" };
        for (int i = 0; i < inspectionResults.Length; i++)
        {
            if (!validResults.Contains(inspectionResults[i]))
            {
                TempData["Error"] = $"Invalid inspection result at item {i + 1}.";
                return RedirectToAction(nameof(InspectRequest), new { requestid = requestId });
            }
        }

        await using var transaction = await _context.Database.BeginTransactionAsync(IsolationLevel.Serializable);
        try
        {
            for (int i = 0; i < borrowingEquipmentItemIds.Length; i++)
            {
                var unit = inUseUnits.FirstOrDefault(u => u.BorrowingEquipmentItemId == borrowingEquipmentItemIds[i]);
                if (unit == null)
                    throw new InvalidOperationException($"Item {borrowingEquipmentItemIds[i]} is not awaiting inspection on this request.");

                if (unit.EquipmentItem == null)
                    throw new InvalidOperationException($"Unit {unit.BorrowingEquipmentItemId} has no assigned equipment item.");

                var inspectionResult = inspectionResults[i];
                // Set status based on inspection result: Returned=Available, Damaged=Damaged, Lost=Lost
                unit.EquipmentItem.Status = inspectionResult == "Returned" ? "Available" : inspectionResult;
                unit.ReturnDate = DateTime.UtcNow;
                unit.Status = "Completed";

                await RecalculateEquipmentAvailabilityAsync(unit.EquipmentItem.EquipmentID);
            }

            foreach (var borrowing in request.Borrowings)
            {
                borrowing.Status = CalculateBorrowingStatus(borrowing.AssignedItems);
                SyncBorrowingReturnDate(borrowing);
            }

            // Set request's return date to today when inspection is completed
            request.ReturnDate = DateTime.UtcNow;
            request.Status = CalculateRequestStatus(request.Borrowings);

            await _context.SaveChangesAsync();
            await transaction.CommitAsync();

            TempData["Success"] = "Inspection completed successfully! All items have been processed.";
            return RedirectToAction(nameof(AdminDashboard));
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            TempData["Error"] = $"Error completing inspection: {ex.Message}";
            return RedirectToAction(nameof(InspectRequest), new { requestid = requestId });
        }
    }

    // GET: BORROWINGS/Inspect/5
    // Single-unit "Inspect and Return" view, reached directly from the In-Use items list.
    public async Task<IActionResult> Inspect(int? borrowingEquipmentItemId)
    {
        if (borrowingEquipmentItemId == null)
            return NotFound();

        var unit = await LoadBorrowingEquipmentItemAsync(borrowingEquipmentItemId.Value);

        if (unit == null)
            return NotFound();

        if (unit.Status != "In-Use")
        {
            TempData["Error"] = "This item is not currently available for inspection.";
            return RedirectToAction(nameof(ViewRequestAdminInUse), new { requestid = unit.Borrowing?.RequestId });
        }

        return View(unit);
    }

    // POST: BORROWINGS/Inspect/5
    // Recording an inspection result here both marks the item returned and completes it in one step.
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Inspect(int? borrowingEquipmentItemId, [Bind("BorrowingEquipmentItemId")] BorrowingEquipmentItem unitInput, string inspectionResult)
    {
        if (borrowingEquipmentItemId == null || borrowingEquipmentItemId != unitInput.BorrowingEquipmentItemId)
            return NotFound();

        if (inspectionResult != "Damaged" && inspectionResult != "Returned" && inspectionResult != "Lost")
        {
            ModelState.AddModelError("", "Invalid inspection result.");
            var invalidUnit = await LoadBorrowingEquipmentItemAsync(borrowingEquipmentItemId.Value);
            return View(invalidUnit ?? unitInput);
        }

        var existing = await _context.BorrowingEquipmentItem
            .Include(bei => bei.EquipmentItem)
            .Include(bei => bei.Borrowing)
                .ThenInclude(b => b.AssignedItems)
            .FirstOrDefaultAsync(bei => bei.BorrowingEquipmentItemId == borrowingEquipmentItemId);

        if (existing == null)
            return NotFound();

        if (existing.Status != "In-Use")
        {
            TempData["Error"] = "This item is not currently awaiting inspection.";
            return RedirectToAction(nameof(AdminDashboard));
        }

        await using var transaction = await _context.Database.BeginTransactionAsync(IsolationLevel.Serializable);
        try
        {
            if (existing.EquipmentItem == null)
                throw new InvalidOperationException("This item has no assigned equipment item.");

            // Set status based on inspection result: Returned=Available, Damaged=Damaged, Lost=Lost
            existing.EquipmentItem.Status = inspectionResult == "Returned" ? "Available" : inspectionResult;
            existing.ReturnDate = DateTime.UtcNow;
            existing.Status = "Completed";

            await RecalculateEquipmentAvailabilityAsync(existing.EquipmentItem.EquipmentID);
            await SyncBorrowingStatusAsync(existing.BorrowingId);
            await SyncRequestStatusAsync(existing.Borrowing.RequestId);
            await _context.SaveChangesAsync();
            await transaction.CommitAsync();

            TempData["Success"] = "Item inspected and returned successfully.";

            var remainingInUse = await _context.BorrowingEquipmentItem
                .AnyAsync(bei => bei.BorrowingId == existing.BorrowingId && bei.Status == "In-Use")
                || await _context.Borrowing
                    .Where(b => b.RequestId == existing.Borrowing.RequestId && b.BorrowingId != existing.BorrowingId)
                    .SelectMany(b => b.AssignedItems)
                    .AnyAsync(ai => ai.Status == "In-Use");

            if (remainingInUse)
                return RedirectToAction(nameof(ViewRequestAdminInUse), new { requestid = existing.Borrowing.RequestId });

            return RedirectToAction(nameof(AdminDashboard));
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            ModelState.AddModelError("", ex.Message);
            var errorUnit = await LoadBorrowingEquipmentItemAsync(borrowingEquipmentItemId.Value);
            return View(errorUnit ?? unitInput);
        }
    }

    // GET: BORROWINGS/InspectAll/5
    public async Task<IActionResult> InspectAll(int? requestid)
    {
        if (requestid == null)
            return NotFound();

        return RedirectToAction(nameof(InspectRequest), new { requestid });
    }

    // GET: api/equipment/list
    [HttpGet]
    [Route("api/equipment/list")]
    public async Task<IActionResult> GetEquipmentList()
    {
        var equipment = await _context.Equipment
            .Select(e => new
            {
                equipmentID = e.EquipmentID,
                equipmentName = e.EquipmentName,
                equipmentAvailableQuantity = e.EquipmentAvailableQuantity
            })
            .ToListAsync();

        return Json(equipment);
    }

    // GET: BORROWINGS/ViewRequestAdmin/5
    [Authorize(Roles = "Admin,Technician")]
    public async Task<IActionResult> ViewRequestAdmin(int? requestid)
    {
        if (requestid == null)
            return NotFound();

        var request = await _context.BorrowingRequests
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.Equipment)
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.AssignedItems)
                    .ThenInclude(ai => ai.EquipmentItem)
            .FirstOrDefaultAsync(r => r.RequestId == requestid);

        if (request == null)
            return NotFound();

        return View(request.Borrowings);
    }

    // GET: BORROWINGS/ViewRequestAdminInUse/5
    [Authorize(Roles = "Admin,Technician")]
    public async Task<IActionResult> ViewRequestAdminInUse(int? requestid)
    {
        if (requestid == null)
            return NotFound();

        var request = await _context.BorrowingRequests
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.Equipment)
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.AssignedItems)
                    .ThenInclude(ai => ai.EquipmentItem)
            .FirstOrDefaultAsync(r => r.RequestId == requestid);

        if (request == null)
            return NotFound();

        return View(request.Borrowings);
    }

    // GET: BORROWINGS/ViewRequest/5
    public async Task<IActionResult> ViewRequest(int? requestid)
    {
        if (requestid == null)
            return NotFound();

        var request = await _context.BorrowingRequests
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.Equipment)
            .Include(r => r.Borrowings)
                .ThenInclude(b => b.AssignedItems)
                    .ThenInclude(ai => ai.EquipmentItem)
            .FirstOrDefaultAsync(r => r.RequestId == requestid);

        return request == null ? NotFound() : View(request);
    }

    // Helper methods
    private void ValidateCreateModel(CreateBorrowingViewModel viewModel)
    {
        if (viewModel.SelectedEquipmentIds == null || viewModel.SelectedEquipmentIds.Count == 0)
            ModelState.AddModelError("SelectedEquipmentIds", "You must select at least one equipment item.");

        if (viewModel.SelectedQuantities == null || viewModel.SelectedQuantities.Count == 0)
            ModelState.AddModelError("SelectedQuantities", "Quantities must be specified.");

        if (viewModel.SelectedEquipmentIds != null && viewModel.SelectedQuantities != null &&
            viewModel.SelectedEquipmentIds.Count != viewModel.SelectedQuantities.Count)
        {
            ModelState.AddModelError("SelectedQuantities", "Equipment count and quantity count must match.");
        }

        if (viewModel.SelectedQuantities != null)
        {
            for (int i = 0; i < viewModel.SelectedQuantities.Count; i++)
            {
                if (viewModel.SelectedQuantities[i] < 1 || viewModel.SelectedQuantities[i] > 99)
                {
                    ModelState.AddModelError("SelectedQuantities", $"Quantity must be between 1 and 99.");
                    break;
                }
            }
        }
    }

    private async Task<CreateBorrowingViewModel> BuildCreateViewModelAsync()
    {
        var currentName = User.FindFirst(System.Security.Claims.ClaimTypes.GivenName)?.Value;
        var surname = User.FindFirst(System.Security.Claims.ClaimTypes.Surname)?.Value;
        var fullName = $"{currentName} {surname}".Trim();
        var username = User.Identity?.Name ?? string.Empty;
        var borrowerName = string.IsNullOrWhiteSpace(fullName) ? username : fullName;

        var division = await _context.Users
            .Where(u => u.Username == username)
            .Select(u => u.UserDivision)
            .FirstOrDefaultAsync() ?? string.Empty;

        return new CreateBorrowingViewModel
        {
            BorrowerName = borrowerName,
            BorrowerDivision = division,
            EquipmentList = await GetBorrowableEquipmentAsync(),
            SelectedEquipmentIds = new List<int>(),
            SelectedQuantities = new List<int>()
        };
    }

    // Equipment with nothing available (0 available quantity, or 0 items at all) shouldn't
    // be offered when requesting new borrowings. reservedEquipmentIds lets an in-progress
    // edit keep showing equipment it already has selected, even if that equipment now has
    // 0 available elsewhere.
    private async Task<List<Equipment>> GetBorrowableEquipmentAsync(IEnumerable<int>? reservedEquipmentIds = null)
    {
        var reserved = (reservedEquipmentIds ?? Enumerable.Empty<int>()).ToHashSet();

        return await _context.Equipment
            .Where(e => e.EquipmentAvailableQuantity > 0 || reserved.Contains(e.EquipmentID))
            .OrderBy(e => e.EquipmentName)
            .ToListAsync();
    }

    private async Task<List<EquipmentItem>> GetAvailableEquipmentItemsAsync(int equipmentId)
    {
        return await _context.EquipmentItem
            .Where(ei => ei.EquipmentID == equipmentId && ei.Status == "Available")
            .OrderBy(ei => ei.ItemLabel)
            .ToListAsync();
    }

    private async Task<BorrowingEquipmentItem?> LoadBorrowingEquipmentItemAsync(int borrowingEquipmentItemId)
    {
        return await _context.BorrowingEquipmentItem
            .Include(bei => bei.Borrowing)
                .ThenInclude(b => b.Equipment)
            .Include(bei => bei.EquipmentItem)
            .FirstOrDefaultAsync(bei => bei.BorrowingEquipmentItemId == borrowingEquipmentItemId);
    }

    private async Task RecalculateEquipmentAvailabilityAsync(int equipmentId)
    {
        var equipment = await _context.Equipment
            .Include(e => e.EquipmentItems)
            .FirstOrDefaultAsync(e => e.EquipmentID == equipmentId);

        if (equipment == null)
            return;

        equipment.EquipmentQuantity = equipment.EquipmentItems.Count;
        equipment.EquipmentAvailableQuantity = equipment.EquipmentItems
            .Count(i => string.Equals(i.Status, "Available", StringComparison.OrdinalIgnoreCase));
    }

    // Recomputes a single Borrowing line's rollup Status from its assigned units.
    private async Task SyncBorrowingStatusAsync(int borrowingId)
    {
        var borrowing = await _context.Borrowing
            .Include(b => b.AssignedItems)
            .FirstOrDefaultAsync(b => b.BorrowingId == borrowingId);

        if (borrowing != null)
        {
            borrowing.Status = CalculateBorrowingStatus(borrowing.AssignedItems);
            SyncBorrowingReturnDate(borrowing);
        }
    }

    // Mirrors SyncRequestStatusAsync's ReturnDate rollup, one level down: once a line's
    // Status becomes Completed, stamp it with the latest ReturnDate of its assigned units.
    private static void SyncBorrowingReturnDate(Borrowing borrowing)
    {
        if (borrowing.Status != "Completed" || borrowing.ReturnDate.HasValue)
            return;

        var completedDates = borrowing.AssignedItems
            .Where(ai => ai.ReturnDate.HasValue)
            .Select(ai => ai.ReturnDate!.Value)
            .ToList();

        borrowing.ReturnDate = completedDates.Any() ? completedDates.Max() : DateTime.UtcNow;
    }

    private async Task SyncRequestStatusAsync(int requestId)
    {
        var request = await _context.BorrowingRequests
            .Include(r => r.Borrowings)
            .FirstOrDefaultAsync(r => r.RequestId == requestId);

        if (request != null)
            request.Status = CalculateRequestStatus(request.Borrowings);

        if (request.Status == "Completed" && !request.ReturnDate.HasValue)
        {
            var completedDates = request.Borrowings
                .SelectMany(b => b.AssignedItems)
                .Where(ai => ai.ReturnDate.HasValue)
                .Select(ai => ai.ReturnDate!.Value)
                .ToList();

            request.ReturnDate = completedDates.Any() ? completedDates.Max() : DateTime.UtcNow;
        }
    }

    // Rolls up a Borrowing line's Status from the statuses of its assigned units.
    // Mirrors CalculateRequestStatus one level down (units -> line, instead of lines -> request).
    private static string CalculateBorrowingStatus(IEnumerable<BorrowingEquipmentItem> assignedItems)
    {
        var statuses = assignedItems.Select(i => i.Status).ToList();

        if (statuses.Count == 0)
            return "Pending";

        if (statuses.All(s => s == "Completed"))
            return "Completed";

        if (statuses.Any(s => s == "Returned"))
            return "Under Inspection";

        if (statuses.Any(s => s == "In-Use"))
            return "In-Use";

        return statuses.First();
    }

    private static string CalculateRequestStatus(IEnumerable<Borrowing> borrowings)
    {
        var statuses = borrowings.Select(b => b.Status).ToList();

        if (statuses.Count == 0)
            return "Cancelled";

        // If any items are rejected, mark the whole request as rejected
        if (statuses.Any(s => s == "Rejected"))
            return "Rejected";

        if (statuses.All(s => s == "Completed"))
            return "Completed";

        if (statuses.Any(s => s == "Returned" || s == "Under Inspection"))
            return "Under Inspection";

        if (statuses.Any(s => s == "Pending"))
            return "Pending";

        if (statuses.Any(s => s == "In-Use"))
            return "Confirmed";

        return statuses.First();
    }

    private static DateTime ToUtc(DateTime date)
    {
        if (date.Kind == DateTimeKind.Unspecified || date.TimeOfDay == TimeSpan.Zero)
        {
            return DateTime.SpecifyKind(date, DateTimeKind.Utc);
        }

        return date.Kind switch
        {
            DateTimeKind.Utc => date,
            DateTimeKind.Local => date.ToUniversalTime(),
            _ => DateTime.SpecifyKind(date, DateTimeKind.Utc)
        };
    }

    private static string GetDatabaseError(DbUpdateException ex)
    {
        return $"Database error: {ex.InnerException?.Message ?? ex.Message}";
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Prototype_Capstone_2.Services;

namespace Prototype_Capstone_2.Controllers
{
    [Authorize]
    public class NotificationsController : Controller
    {
        private readonly NotificationService _notificationService;

        public NotificationsController(NotificationService notificationService)
        {
            _notificationService = notificationService;
        }

        [HttpGet]
        public async Task<IActionResult> GetNotifications()
        {
            var username = User.Identity?.Name ?? string.Empty;
            var roles = User.FindAll(System.Security.Claims.ClaimTypes.Role).Select(c => c.Value).ToList();

            dynamic result = new { totalCount = 0, notifications = new List<object>() };

            if (roles.Contains("Admin"))
            {
                var adminNotifications = await _notificationService.GetAdminNotificationsAsync();
                result = new
                {
                    totalCount = adminNotifications.TotalNotifications,
                    notifications = adminNotifications.Notifications
                };
            }
            else if (roles.Contains("Technician"))
            {
                var techNotifications = await _notificationService.GetTechnicianNotificationsAsync(username);
                result = new
                {
                    totalCount = techNotifications.TotalNotifications,
                    notifications = techNotifications.Notifications
                };
            }
            else
            {
                var empNotifications = await _notificationService.GetEmployeeNotificationsAsync(username);
                result = new
                {
                    totalCount = empNotifications.TotalNotifications,
                    notifications = empNotifications.Notifications
                };
            }

            return Ok(result);
        }
    }
}

﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Prototype_Capstone_2.Models;

[Authorize(Roles = "Admin,Technician")]
public class EquipmentController : Controller
{
    private readonly Prototype_Capstone_2Context _context;

    public EquipmentController(Prototype_Capstone_2Context context)
    {
        _context = context;
    }

    // GET: EQUIPMENTS
    public async Task<IActionResult> Index(string? searchString)
    {
        var equipment = from e in _context.Equipment select e;

        if (!string.IsNullOrEmpty(searchString))
        {
            equipment = equipment.Where(e => 
                e.EquipmentName.Contains(searchString) || 
                e.EquipmentDesc.Contains(searchString));
        }

        ViewData["SearchString"] = searchString;
        return View(await equipment.ToListAsync());
    }

    // GET: EQUIPMENTS/Details/5
    public async Task<IActionResult> Details(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var equipment = await _context.Equipment
            .Include(e => e.EquipmentItems)
            .FirstOrDefaultAsync(m => m.EquipmentID == id);
        if (equipment == null)
        {
            return NotFound();
        }

        return View(equipment);
    }

    //GET EQUIPMENTS/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST EQUIPMENTS/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("EquipmentName,EquipmentDesc")] Equipment equipment)
    {
        // Remove validation errors for quantity fields since we're not accepting them
        ModelState.Remove("EquipmentQuantity");
        ModelState.Remove("EquipmentAvailableQuantity");
        ModelState.Remove("EquipmentDateCreated");

        if (ModelState.IsValid)
        {
            // Set default values
            equipment.EquipmentQuantity = 0;
            equipment.EquipmentAvailableQuantity = 0;
            equipment.EquipmentDateCreated = DateTime.UtcNow;

            _context.Add(equipment);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        return View(equipment);
    }

    // GET EQUIPMENTS/Edit/5
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var equipment = await _context.Equipment.FindAsync(id);
        if (equipment == null)
        {
            return NotFound();
        }
        return View(equipment);
    }

    // POST EQUIPMENTS/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int? id, [Bind("EquipmentID,EquipmentName,EquipmentDesc")] Equipment equipment)
    {
        if (id != equipment.EquipmentID)
        {
            return NotFound();
        }

        // Get existing equipment to preserve quantities and date
        var existingEquipment = await _context.Equipment.FindAsync(id);
        if (existingEquipment == null)
        {
            return NotFound();
        }

        // update name and description
        existingEquipment.EquipmentName = equipment.EquipmentName;
        existingEquipment.EquipmentDesc = equipment.EquipmentDesc;

        ModelState.Remove("EquipmentQuantity");
        ModelState.Remove("EquipmentAvailableQuantity");
        ModelState.Remove("EquipmentDateCreated");

        if (ModelState.IsValid)
        {
            try
            {
                _context.Update(existingEquipment);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EquipmentExists(equipment.EquipmentID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return RedirectToAction("Details", new { id = equipment.EquipmentID });
        }
        return View(equipment);
    }

    // GET EQUIPMENTS/Delete/5
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var equipment = await _context.Equipment
            .FirstOrDefaultAsync(m => m.EquipmentID == id);
        if (equipment == null)
        {
            return NotFound();
        }

        return View(equipment);
    }

    // POST EQUIPMENTS/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int? id)
    {
        if (id == null)
            return NotFound();

        var equipment = await _context.Equipment.FindAsync(id);
        if (equipment == null)
            return NotFound();

        // Do not cascade-delete equipment together with borrowing history.
        var hasBorrowingHistory = await _context.Borrowing.AnyAsync(b => b.EquipmentID == id);
        if (hasBorrowingHistory)
        {
            TempData["Error"] = "This equipment cannot be deleted because it has borrowing history. Keep the record for audit/history purposes.";
            return RedirectToAction(nameof(Details), new { id });
        }

        var hasItems = await _context.EquipmentItem.AnyAsync(i => i.EquipmentID == id);
        if (hasItems)
        {
            TempData["Error"] = "Remove or deactivate the equipment items before deleting this equipment.";
            return RedirectToAction(nameof(Details), new { id });
        }

        _context.Equipment.Remove(equipment);
        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    private bool EquipmentExists(int? id)
    {
        return _context.Equipment.Any(e => e.EquipmentID == id);
    }
}

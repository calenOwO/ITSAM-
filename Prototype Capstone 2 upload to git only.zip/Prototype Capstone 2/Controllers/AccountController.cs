using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Prototype_Capstone_2.Models;

namespace Prototype_Capstone_2.Controllers
{
    public class AccountController : Controller
    {
        private readonly Prototype_Capstone_2Context _context;
        private readonly PasswordHasher<Users> _passwordHasher = new();

        public AccountController(Prototype_Capstone_2Context context)
        {
            _context = context;
        }

        [AllowAnonymous]
        public IActionResult Login(string? returnUrl = null)
        {
            if (User.Identity?.IsAuthenticated == true)
                return RedirectToDashboard(User.FindFirst(ClaimTypes.Role)?.Value ?? string.Empty);

            return View(new LoginViewModel { ReturnUrl = returnUrl });
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var username = model.Username.Trim();
            var account = await _context.Users.FirstOrDefaultAsync(u => u.Username.ToLower() == username.ToLower());

            if (account == null || !VerifyPassword(account, model.Password))
            {
                ModelState.AddModelError(string.Empty, "Invalid username or password.");
                return View(model);
            }

            // Check if user is approved
            if (account.ApprovalStatus != "Approved")
            {
                ModelState.AddModelError(string.Empty, "Your account is pending admin approval. Please wait for approval before logging in.");
                return View(model);
            }

            var claims = new List<Claim>
            {
                new(ClaimTypes.NameIdentifier, account.UserId.ToString()),
                new(ClaimTypes.Name, account.Username),
                new(ClaimTypes.Role, account.UserRole),
                new(ClaimTypes.GivenName, account.FirstName),
                new(ClaimTypes.Surname, account.LastName)
            };

            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            var principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                principal,
                new AuthenticationProperties
                {
                    IsPersistent = model.RememberMe,
                    AllowRefresh = true
                });

            if (!string.IsNullOrWhiteSpace(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
                return Redirect(model.ReturnUrl);

            return RedirectToDashboard(account.UserRole);
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction(nameof(Login));
        }

        [AllowAnonymous]
        public IActionResult AccessDenied() => View();

        [AllowAnonymous]
        public IActionResult Register()
        {
            if (User.Identity?.IsAuthenticated == true)
                return RedirectToDashboard(User.FindFirst(ClaimTypes.Role)?.Value ?? string.Empty);

            PopulateRegisterLists();
            return View(new RegisterViewModel());
        }

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
            {
                PopulateRegisterLists();
                return View(model);
            }

          
            var validRoles = new[] { "Employee", "Technician", "Admin" };
            var validDivisions = new[] { "Operations", "IT Operations", "Marketing", "Human Resources" };

            if (!validRoles.Contains(model.Role))
            {
                ModelState.AddModelError("Role", "Invalid role selected.");
                PopulateRegisterLists();
                return View(model);
            }

            if (!validDivisions.Contains(model.Division))
            {
                ModelState.AddModelError("Division", "Invalid division selected.");
                PopulateRegisterLists();
                return View(model);
            }

            // Check if username exists
            var usernameExists = await _context.Users.AnyAsync(u => u.Username.ToLower() == model.Username.ToLower());
            if (usernameExists)
            {
                ModelState.AddModelError("Username", "Username is already taken. Please choose a different username.");
                PopulateRegisterLists();
                return View(model);
            }

            // Check if email exists
            var emailExists = await _context.Users.AnyAsync(u => u.Email.ToLower() == model.Email.ToLower());
            if (emailExists)
            {
                ModelState.AddModelError("Email", "Email is already registered. Please use a different email or log in.");
                PopulateRegisterLists();
                return View(model);
            }

            try
            {
                
                var newUser = new Users
                {
                    FirstName = model.FirstName.Trim(),
                    LastName = model.LastName.Trim(),
                    Email = model.Email.Trim().ToLower(),
                    PhoneNumber = model.PhoneNumber.Trim(),
                    UserDivision = model.Division.Trim(),
                    Username = model.Username.Trim(),
                    UserRole = model.Role,
                    ApprovalStatus = "Pending", 
                    UserCreated = DateTime.UtcNow
                };

                // Hash password
                newUser.PasswordHash = _passwordHasher.HashPassword(newUser, model.Password);

                // Add to database
                _context.Users.Add(newUser);
                await _context.SaveChangesAsync();

                // Redirect to login with success message
                TempData["SuccessMessage"] = "Registration successful! Your account is pending admin approval. You will be able to log in once approved.";
                return RedirectToAction(nameof(Login));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"An error occurred during registration: {ex.Message}");
                PopulateRegisterLists();
                return View(model);
            }
        }

        // Dashboard() on HomeController branches by role internally (renders
        // AdminDashboard/TechnicianDashboard/Dashboard views), so every role
        // redirects to the same single action.
        private IActionResult RedirectToDashboard(string role)
        {
            return RedirectToAction("Dashboard", "Home");
        }

        private void PopulateRegisterLists()
        {
            ViewBag.Divisions = new[] { "Operations", "IT Operations", "Marketing", "Human Resources" };
            ViewBag.Roles = new[] { "Employee", "Technician", "Admin" };
        }

        private bool VerifyPassword(Users account, string enteredPassword)
        {
            if (string.IsNullOrEmpty(account.PasswordHash))
                return false;

            var result = _passwordHasher.VerifyHashedPassword(account, account.PasswordHash, enteredPassword);
            if (result == PasswordVerificationResult.Success || result == PasswordVerificationResult.SuccessRehashNeeded)
            {
                if (result == PasswordVerificationResult.SuccessRehashNeeded)
                    account.PasswordHash = _passwordHasher.HashPassword(account, enteredPassword);
                return true;
            }

            // Backward compatibility for accounts created before password hashing was added.
            // The plaintext value is immediately replaced with a secure salted PBKDF2 hash.
            var storedBytes = Encoding.UTF8.GetBytes(account.PasswordHash);
            var enteredBytes = Encoding.UTF8.GetBytes(enteredPassword);
            var matches = storedBytes.Length == enteredBytes.Length && CryptographicOperations.FixedTimeEquals(storedBytes, enteredBytes);
            if (!matches)
                return false;

            account.PasswordHash = _passwordHasher.HashPassword(account, enteredPassword);
            _context.SaveChanges();
            return true;
        }
    }
}
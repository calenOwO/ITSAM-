using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Prototype_Capstone_2.Migrations
{
    public partial class SimplifyTicketing : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Remove excess columns
            migrationBuilder.DropColumn(
                name: "TicketTimeOfIncident",
                table: "Ticketing");

            migrationBuilder.DropColumn(
                name: "TicketPlaceOfIncident",
                table: "Ticketing");

            migrationBuilder.DropColumn(
                name: "TicketImmediateResponse",
                table: "Ticketing");

            // Rename TicketDateOfIncident to TicketDateCreated
            migrationBuilder.RenameColumn(
                name: "TicketDateOfIncident",
                table: "Ticketing",
                newName: "TicketDateCreated");

            // Make TicketPersonNotified nullable string
            migrationBuilder.AlterColumn<string>(
                name: "TicketPersonNotified",
                table: "Ticketing",
                type: "character varying(100)",
                maxLength: 100,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100);

            // Drop the old TicketTimeFixed column and create a new one with proper type
            migrationBuilder.DropColumn(
                name: "TicketTimeFixed",
                table: "Ticketing");

            migrationBuilder.AddColumn<DateTime>(
                name: "TicketTimeFixed",
                table: "Ticketing",
                type: "timestamp with time zone",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Drop new TicketTimeFixed and restore as string
            migrationBuilder.DropColumn(
                name: "TicketTimeFixed",
                table: "Ticketing");

            migrationBuilder.AddColumn<string>(
                name: "TicketTimeFixed",
                table: "Ticketing",
                type: "text",
                nullable: false,
                defaultValue: "");

            // Restore TicketPersonNotified as non-nullable
            migrationBuilder.AlterColumn<string>(
                name: "TicketPersonNotified",
                table: "Ticketing",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "character varying(100)",
                oldMaxLength: 100,
                oldNullable: true);

            // Rename back
            migrationBuilder.RenameColumn(
                name: "TicketDateCreated",
                table: "Ticketing",
                newName: "TicketDateOfIncident");

            // Add back removed columns
            migrationBuilder.AddColumn<string>(
                name: "TicketTimeOfIncident",
                table: "Ticketing",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "TicketPlaceOfIncident",
                table: "Ticketing",
                type: "character varying(150)",
                maxLength: 150,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "TicketImmediateResponse",
                table: "Ticketing",
                type: "character varying(1000)",
                maxLength: 1000,
                nullable: false,
                defaultValue: "");
        }
    }
}

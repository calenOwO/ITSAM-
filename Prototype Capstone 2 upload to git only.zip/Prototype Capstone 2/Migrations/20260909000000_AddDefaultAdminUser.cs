using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Prototype_Capstone_2.Migrations
{
    /// <inheritdoc />
    public partial class AddDefaultAdminUser : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Only insert the default admin user if no admin accounts exist
            migrationBuilder.Sql(@"
                INSERT INTO ""Users"" (""UserName"", ""UserPassword"", ""UserEmail"", ""FirstName"", ""LastName"", ""UserRole"", ""UserDivision"", ""PhoneNumber"", ""UserCreated"", ""ApprovalStatus"")
                SELECT 'admin', 'AQAAAAIAAYagAAAAEB3p5vQv4z4qNRVJU3l8TnY/XPBnEFqKQKLQmPWJOhKM5z9xqCKkBfqvXJSyv3g6Iw==', 'admin@envicomm.com', 'Admin', 'User', 'Admin', 'Administration', '1234567890', NOW() AT TIME ZONE 'UTC', 'Approved'
                WHERE NOT EXISTS (SELECT 1 FROM ""Users"" WHERE ""UserRole"" = 'Admin')
            ");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Only delete if we inserted it (check by username and email to be safe)
            migrationBuilder.Sql(@"
                DELETE FROM ""Users"" 
                WHERE ""UserName"" = 'admin' 
                AND ""UserEmail"" = 'admin@envicomm.com'
                AND NOT EXISTS (SELECT 1 FROM ""Users"" WHERE ""UserRole"" = 'Admin' AND ""UserId"" != ""UserId"")
            ");
        }
    }
}

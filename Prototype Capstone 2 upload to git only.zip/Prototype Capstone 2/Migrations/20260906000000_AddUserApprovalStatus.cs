using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Prototype_Capstone_2.Migrations
{
    /// <inheritdoc />
    public partial class AddUserApprovalStatus : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
-- Add ApprovalStatus column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='Users' AND column_name='ApprovalStatus') THEN
        ALTER TABLE ""Users"" ADD COLUMN ""ApprovalStatus"" character varying(20) NOT NULL DEFAULT 'Approved';
    END IF;
END $$;
");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql(@"
ALTER TABLE ""Users"" DROP COLUMN IF EXISTS ""ApprovalStatus"";
");
        }
    }
}

using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;
using Prototype_Capstone_2;

#nullable disable

namespace Prototype_Capstone_2.Migrations
{
    [DbContext(typeof(Prototype_Capstone_2Context))]
    [Migration("20260828000000_SimplifyTicketing")]
    partial class SimplifyTicketing
    {
        /// <inheritdoc />
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
#pragma warning disable 612, 618
            modelBuilder
                .HasAnnotation("ProductVersion", "8.0.0")
                .HasAnnotation("Relational:MaxIdentifierLength", 63);

            NpgsqlModelBuilderExtensions.UseIdentityByDefaultColumns(modelBuilder);

            modelBuilder.Entity("Prototype_Capstone_2.Models.BorrowingEquipmentItem", b =>
                {
                    b.Property<int>("ItemId")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("integer");

                    NpgsqlPropertyBuilderExtensions.UseIdentityByDefaultColumn(b.Property<int>("ItemId"));

                    b.Property<int>("BorrowingId")
                        .HasColumnType("integer");

                    b.Property<DateTime>("InspectionDate")
                        .HasColumnType("timestamp with time zone");

                    b.Property<string>("InspectionNotes")
                        .IsRequired()
                        .HasColumnType("text");

                    b.Property<int>("PhysicalItemId")
                        .HasColumnType("integer");

                    b.Property<DateTime?>("ReturnDate")
                        .HasColumnType("timestamp with time zone");

                    b.Property<string>("Status")
                        .IsRequired()
                        .HasColumnType("text");

                    b.HasKey("ItemId");

                    b.HasIndex("BorrowingId");

                    b.HasIndex("PhysicalItemId");

                    b.ToTable("BorrowingEquipmentItems");
                });

            modelBuilder.Entity("Prototype_Capstone_2.Models.BorrowingRequests", b =>
                {
                    b.Property<int>("RequestId")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("integer");

                    NpgsqlPropertyBuilderExtensions.UseIdentityByDefaultColumn(b.Property<int>("RequestId"));

                    b.Property<DateTime>("CreatedDate")
                        .HasColumnType("timestamp with time zone");

                    b.Property<string>("RequestStatus")
                        .IsRequired()
                        .HasColumnType("text");

                    b.HasKey("RequestId");

                    b.ToTable("BorrowingRequests");
                });

            modelBuilder.Entity("Prototype_Capstone_2.Models.Borrowing", b =>
                {
                    b.Property<int>("BorrowingId")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("integer");

                    NpgsqlPropertyBuilderExtensions.UseIdentityByDefaultColumn(b.Property<int>("BorrowingId"));

                    b.Property<DateTime>("BorrowDate")
                        .HasColumnType("timestamp with time zone");

                    b.Property<string>("BorrowerName")
                        .IsRequired()
                        .HasMaxLength(50)
                        .HasColumnType("character varying(50)");

                    b.Property<int>("EquipmentID")
                        .HasColumnType("integer");

                    b.Property<int>("Quantity")
                        .HasColumnType("integer");

                    b.Property<int>("RequestId")
                        .HasColumnType("integer");

                    b.Property<DateTime?>("ReturnDate")
                        .HasColumnType("timestamp with time zone");

                    b.Property<string>("Status")
                        .IsRequired()
                        .HasColumnType("text");

                    b.HasKey("BorrowingId");

                    b.HasIndex("EquipmentID");

                    b.HasIndex("RequestId");

                    b.ToTable("Borrowing");
                });

            modelBuilder.Entity("Prototype_Capstone_2.Models.Equipment", b =>
                {
                    b.Property<int>("EquipmentID")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("integer");

                    NpgsqlPropertyBuilderExtensions.UseIdentityByDefaultColumn(b.Property<int>("EquipmentID"));

                    b.Property<DateTime>("DateOfAcquisition")
                        .HasColumnType("timestamp with time zone");

                    b.Property<int>("EquipmentAvailableQuantity")
                        .HasColumnType("integer");

                    b.Property<string>("EquipmentCondition")
                        .IsRequired()
                        .HasColumnType("text");

                    b.Property<string>("EquipmentDescription")
                        .IsRequired()
                        .HasColumnType("text");

                    b.Property<string>("EquipmentName")
                        .IsRequired()
                        .HasMaxLength(100)
                        .HasColumnType("character varying(100)");

                    b.Property<int>("EquipmentQuantity")
                        .HasColumnType("integer");

                    b.Property<string>("EquipmentType")
                        .IsRequired()
                        .HasMaxLength(100)
                        .HasColumnType("character varying(100)");

                    b.HasKey("EquipmentID");

                    b.ToTable("Equipment");
                });

            modelBuilder.Entity("Prototype_Capstone_2.Models.EquipmentItem", b =>
                {
                    b.Property<int>("ItemID")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("integer");

                    NpgsqlPropertyBuilderExtensions.UseIdentityByDefaultColumn(b.Property<int>("ItemID"));

                    b.Property<string>("ItemCondition")
                        .IsRequired()
                        .HasColumnType("text");

                    b.Property<string>("ItemSerialNumber")
                        .IsRequired()
                        .HasMaxLength(50)
                        .HasColumnType("character varying(50)");

                    b.Property<int>("ItemStatus")
                        .HasColumnType("integer");

                    b.Property<int>("ItemType")
                        .HasColumnType("integer");

                    b.HasKey("ItemID");

                    b.ToTable("EquipmentItem");
                });

            modelBuilder.Entity("Prototype_Capstone_2.Models.Ticketing", b =>
                {
                    b.Property<int>("TicketId")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("integer");

                    NpgsqlPropertyBuilderExtensions.UseIdentityByDefaultColumn(b.Property<int>("TicketId"));

                    b.Property<DateTime>("TicketAssignedTo")
                        .HasColumnType("timestamp with time zone");

                    b.Property<DateTime>("TicketCreated")
                        .HasColumnType("timestamp with time zone");

                    b.Property<string>("TicketDateCreated")
                        .IsRequired()
                        .HasColumnType("text");

                    b.Property<string>("TicketDefects")
                        .IsRequired()
                        .HasMaxLength(500)
                        .HasColumnType("character varying(500)");

                    b.Property<string>("TicketDescription")
                        .IsRequired()
                        .HasMaxLength(3000)
                        .HasColumnType("character varying(3000)");

                    b.Property<string>("TicketDivision")
                        .IsRequired()
                        .HasMaxLength(100)
                        .HasColumnType("character varying(100)");

                    b.Property<string>("TicketEquipment")
                        .IsRequired()
                        .HasMaxLength(100)
                        .HasColumnType("character varying(100)");

                    b.Property<string>("TicketIssueCategory")
                        .IsRequired()
                        .HasMaxLength(100)
                        .HasColumnType("character varying(100)");

                    b.Property<string>("TicketPersonNotified")
                        .HasMaxLength(100)
                        .HasColumnType("character varying(100)");

                    b.Property<string>("TicketPosition")
                        .IsRequired()
                        .HasMaxLength(100)
                        .HasColumnType("character varying(100)");

                    b.Property<string>("TicketPriority")
                        .IsRequired()
                        .HasMaxLength(50)
                        .HasColumnType("character varying(50)");

                    b.Property<string>("TicketResolution")
                        .IsRequired()
                        .HasMaxLength(3000)
                        .HasColumnType("character varying(3000)");

                    b.Property<string>("TicketStatus")
                        .IsRequired()
                        .HasMaxLength(50)
                        .HasColumnType("character varying(50)");

                    b.Property<DateTime?>("TicketTimeFixed")
                        .HasColumnType("timestamp with time zone");

                    b.Property<string>("TicketUserName")
                        .IsRequired()
                        .HasMaxLength(100)
                        .HasColumnType("character varying(100)");

                    b.HasKey("TicketId");

                    b.ToTable("Ticketing");
                });

            modelBuilder.Entity("Prototype_Capstone_2.Models.Users", b =>
                {
                    b.Property<int>("UserId")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("integer");

                    NpgsqlPropertyBuilderExtensions.UseIdentityByDefaultColumn(b.Property<int>("UserId"));

                    b.Property<string>("UserEmail")
                        .IsRequired()
                        .HasColumnType("text");

                    b.Property<string>("UserName")
                        .IsRequired()
                        .HasColumnType("text");

                    b.Property<string>("UserPassword")
                        .IsRequired()
                        .HasColumnType("text");

                    b.HasKey("UserId");

                    b.ToTable("Users");
                });

            modelBuilder.Entity("Prototype_Capstone_2.Models.BorrowingEquipmentItem", b =>
                {
                    b.HasOne("Prototype_Capstone_2.Models.Borrowing", "Borrowing")
                        .WithMany("AssignedItems")
                        .HasForeignKey("BorrowingId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.HasOne("Prototype_Capstone_2.Models.EquipmentItem", "EquipmentItem")
                        .WithMany()
                        .HasForeignKey("PhysicalItemId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.Navigation("Borrowing");

                    b.Navigation("EquipmentItem");
                });

            modelBuilder.Entity("Prototype_Capstone_2.Models.Borrowing", b =>
                {
                    b.HasOne("Prototype_Capstone_2.Models.Equipment", "Equipment")
                        .WithMany()
                        .HasForeignKey("EquipmentID")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.HasOne("Prototype_Capstone_2.Models.BorrowingRequests", "BorrowingRequest")
                        .WithMany()
                        .HasForeignKey("RequestId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.Navigation("BorrowingRequest");

                    b.Navigation("Equipment");
                });

            modelBuilder.Entity("Prototype_Capstone_2.Models.Borrowing", b =>
                {
                    b.Navigation("AssignedItems");
                });
#pragma warning restore 612, 618
        }
    }
}

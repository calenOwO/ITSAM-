﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Prototype_Capstone_2.Migrations
{
    /// <inheritdoc />
    public partial class AddBorrowingQuantityAndUnits : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Borrowing_EquipmentItem_EquipmentItemID",
                table: "Borrowing");

            migrationBuilder.DropIndex(
                name: "IX_Borrowing_EquipmentItemID",
                table: "Borrowing");

            migrationBuilder.DropColumn(
                name: "EquipmentItemID",
                table: "Borrowing");

            migrationBuilder.AddColumn<int>(
                name: "Quantity",
                table: "Borrowing",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "BorrowingEquipmentItem",
                columns: table => new
                {
                    BorrowingEquipmentItemId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    BorrowingId = table.Column<int>(type: "integer", nullable: false),
                    EquipmentItemID = table.Column<int>(type: "integer", nullable: false),
                    Status = table.Column<string>(type: "text", nullable: false),
                    ReturnDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BorrowingEquipmentItem", x => x.BorrowingEquipmentItemId);
                    table.ForeignKey(
                        name: "FK_BorrowingEquipmentItem_Borrowing_BorrowingId",
                        column: x => x.BorrowingId,
                        principalTable: "Borrowing",
                        principalColumn: "BorrowingId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_BorrowingEquipmentItem_EquipmentItem_EquipmentItemID",
                        column: x => x.EquipmentItemID,
                        principalTable: "EquipmentItem",
                        principalColumn: "ItemID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_BorrowingEquipmentItem_BorrowingId",
                table: "BorrowingEquipmentItem",
                column: "BorrowingId");

            migrationBuilder.CreateIndex(
                name: "IX_BorrowingEquipmentItem_EquipmentItemID",
                table: "BorrowingEquipmentItem",
                column: "EquipmentItemID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BorrowingEquipmentItem");

            migrationBuilder.DropColumn(
                name: "Quantity",
                table: "Borrowing");

            migrationBuilder.AddColumn<int>(
                name: "EquipmentItemID",
                table: "Borrowing",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Borrowing_EquipmentItemID",
                table: "Borrowing",
                column: "EquipmentItemID");

            migrationBuilder.AddForeignKey(
                name: "FK_Borrowing_EquipmentItem_EquipmentItemID",
                table: "Borrowing",
                column: "EquipmentItemID",
                principalTable: "EquipmentItem",
                principalColumn: "ItemID");
        }
    }
}

using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;
#nullable disable
namespace Prototype_Capstone_2.Migrations
{
    public partial class AddTicketing : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Ticketing",
                columns: table => new
                {
                    TicketId = table.Column<int>(type: "integer", nullable: false).Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    TicketUserName = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    TicketDivision = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    TicketIssueCategory = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    TicketDateOfIncident = table.Column<DateTime>(type: "date", nullable: false),
                    TicketTimeOfIncident = table.Column<string>(type: "text", nullable: false),
                    TicketPlaceOfIncident = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: false),
                    TicketTimeFixed = table.Column<string>(type: "text", nullable: false),
                    TicketPersonNotified = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    TicketImmediateResponse = table.Column<string>(type: "character varying(1000)", maxLength: 1000, nullable: false),
                    TicketDescription = table.Column<string>(type: "character varying(3000)", maxLength: 3000, nullable: false),
                    TicketResolution = table.Column<string>(type: "character varying(3000)", maxLength: 3000, nullable: false),
                    TicketAssignedTo = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    TicketStatus = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    TicketPriority = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    TicketCreated = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table => { table.PrimaryKey("PK_Ticketing", x => x.TicketId); });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(name: "Ticketing");
        }
    }
}

using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Prototype_Capstone_2.Migrations
{
    /// <inheritdoc />
    public partial class AddUserForeignKeysToRequestsAndTickets : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "RequesterUserId",
                table: "BorrowingRequests",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "SubmittedByUserId",
                table: "Ticketing",
                type: "integer",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "AssignedToUserId",
                table: "Ticketing",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_BorrowingRequests_RequesterUserId",
                table: "BorrowingRequests",
                column: "RequesterUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Ticketing_SubmittedByUserId",
                table: "Ticketing",
                column: "SubmittedByUserId");

            migrationBuilder.CreateIndex(
                name: "IX_Ticketing_AssignedToUserId",
                table: "Ticketing",
                column: "AssignedToUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_BorrowingRequests_Users_RequesterUserId",
                table: "BorrowingRequests",
                column: "RequesterUserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Ticketing_Users_SubmittedByUserId",
                table: "Ticketing",
                column: "SubmittedByUserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Ticketing_Users_AssignedToUserId",
                table: "Ticketing",
                column: "AssignedToUserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BorrowingRequests_Users_RequesterUserId",
                table: "BorrowingRequests");

            migrationBuilder.DropForeignKey(
                name: "FK_Ticketing_Users_SubmittedByUserId",
                table: "Ticketing");

            migrationBuilder.DropForeignKey(
                name: "FK_Ticketing_Users_AssignedToUserId",
                table: "Ticketing");

            migrationBuilder.DropIndex(
                name: "IX_BorrowingRequests_RequesterUserId",
                table: "BorrowingRequests");

            migrationBuilder.DropIndex(
                name: "IX_Ticketing_SubmittedByUserId",
                table: "Ticketing");

            migrationBuilder.DropIndex(
                name: "IX_Ticketing_AssignedToUserId",
                table: "Ticketing");

            migrationBuilder.DropColumn(
                name: "RequesterUserId",
                table: "BorrowingRequests");

            migrationBuilder.DropColumn(
                name: "SubmittedByUserId",
                table: "Ticketing");

            migrationBuilder.DropColumn(
                name: "AssignedToUserId",
                table: "Ticketing");
        }
    }
}

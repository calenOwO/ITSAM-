using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Prototype_Capstone_2.Migrations
{
    /// <inheritdoc />
    public partial class AddBorrowerDivisionToBorrowingRequests : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "BorrowerDivision",
                table: "BorrowingRequests",
                type: "character varying(100)",
                maxLength: 100,
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BorrowerDivision",
                table: "BorrowingRequests");
        }
    }
}

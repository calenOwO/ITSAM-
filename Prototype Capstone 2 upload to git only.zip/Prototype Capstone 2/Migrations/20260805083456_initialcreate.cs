﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Prototype_Capstone_2.Migrations
{
    /// <inheritdoc />
    public partial class initialcreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "BorrowingRequests",
                columns: table => new
                {
                    RequestId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    BorrowerName = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    BorrowDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    ReturnDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    Status = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BorrowingRequests", x => x.RequestId);
                });

            migrationBuilder.CreateTable(
                name: "Equipment",
                columns: table => new
                {
                    EquipmentID = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    EquipmentName = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    EquipmentDesc = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    EquipmentQuantity = table.Column<int>(type: "integer", nullable: false),
                    EquipmentAvailableQuantity = table.Column<int>(type: "integer", nullable: false),
                    EquipmentDateCreated = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Equipment", x => x.EquipmentID);
                });

            migrationBuilder.CreateTable(
                name: "EquipmentItem",
                columns: table => new
                {
                    ItemID = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    EquipmentID = table.Column<int>(type: "integer", nullable: false),
                    ItemLabel = table.Column<string>(type: "text", nullable: false),
                    Status = table.Column<string>(type: "text", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EquipmentItem", x => x.ItemID);
                    table.ForeignKey(
                        name: "FK_EquipmentItem_Equipment_EquipmentID",
                        column: x => x.EquipmentID,
                        principalTable: "Equipment",
                        principalColumn: "EquipmentID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Borrowing",
                columns: table => new
                {
                    BorrowingId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    BorrowerName = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    EquipmentID = table.Column<int>(type: "integer", nullable: false),
                    EquipmentItemID = table.Column<int>(type: "integer", nullable: true),
                    BorrowDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    ReturnDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    Status = table.Column<string>(type: "text", nullable: false),
                    RequestId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Borrowing", x => x.BorrowingId);
                    table.ForeignKey(
                        name: "FK_Borrowing_BorrowingRequests_RequestId",
                        column: x => x.RequestId,
                        principalTable: "BorrowingRequests",
                        principalColumn: "RequestId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Borrowing_EquipmentItem_EquipmentItemID",
                        column: x => x.EquipmentItemID,
                        principalTable: "EquipmentItem",
                        principalColumn: "ItemID");
                    table.ForeignKey(
                        name: "FK_Borrowing_Equipment_EquipmentID",
                        column: x => x.EquipmentID,
                        principalTable: "Equipment",
                        principalColumn: "EquipmentID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Borrowing_EquipmentID",
                table: "Borrowing",
                column: "EquipmentID");

            migrationBuilder.CreateIndex(
                name: "IX_Borrowing_EquipmentItemID",
                table: "Borrowing",
                column: "EquipmentItemID");

            migrationBuilder.CreateIndex(
                name: "IX_Borrowing_RequestId",
                table: "Borrowing",
                column: "RequestId");

            migrationBuilder.CreateIndex(
                name: "IX_EquipmentItem_EquipmentID",
                table: "EquipmentItem",
                column: "EquipmentID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Borrowing");

            migrationBuilder.DropTable(
                name: "BorrowingRequests");

            migrationBuilder.DropTable(
                name: "EquipmentItem");

            migrationBuilder.DropTable(
                name: "Equipment");
        }
    }
}
